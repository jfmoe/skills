# index-value-analysis

| 项 | 值 |
|---|---|
| `api_id` | `index-value-analysis` |
| 服务端登记名 | 指数价值分析 |
| 领域 | index |
| 资料完整度 | 完整（请求 + 响应 + 口径均有；量级口径待线上实测复核，见第 6 节挂账） |

## 1. 功能与适用场景

返回**指数估值面序列**：总市值/流通市值/自由流通市值（亿元）、PE(LYR)/PE(TTM) 与 PE 历史百分位、PB(MRQ)/PB(LF) 与 PB 历史百分位、PCF(LYR)/PCF(TTM)、PS(LYR)/PS(TTM)、股息率与滚动股息率、股债风险溢价、PEG，一行 = 一个指数 × 一个截止日。

适用：用户问「沪深300 现在 PE 多少、处于历史什么分位」「这个指数贵不贵、估值分位多高」「指数股息率和股债性价比」「多只指数估值对比」。

## 2. 不适用场景与易混接口

- 与 `index-daily-quote` 的区别：那个是**逐日行情**（OHLC/成交），无任何估值字段；本接口**不含开高低收**。
- 与 `index-range-quote` 的区别：那个是**区间聚合**涨跌幅与区间高低点。
- 与 `index-multi-period-quote` 的区别：那个是多周期行情序列（按年/季/月/周/日）。
- 与 `index-basic-info` 的区别：那个是**静态资料**（类型/基期基点/发布机构），无估值。
- 与 `index-industry-dist` / `index-constituents` 的区别：那两个是**成分股维度**的行业分布/逐股明细。

## 3. 请求参数

| 参数 | 类型 | 必填 | 规则 |
|---|---|---|---|
| `indexObject` | string[]（兼容单字符串） | **是** | 指数**内码**列表（如 `["631101"]`），或带后缀聚源代码（如 `["000300.SH"]`）；空白元素剔除，全空 → 400 |
| `beginDate` | string | 否 | `yyyy-MM-dd`；不传 = 不下推（上游缺省窗口） |
| `endDate` | string | 否 | `yyyy-MM-dd`；不传 = 不下推（上游缺省窗口） |

> ⚠ **`indexObject` 传内码不要传 6 位净码**：上游只对「含 `.` 的值」做聚源代码→内码转换，纯数字一律按内码解析。
> 传 `000300` 会被当成内码 `300`（取到别的标的或空结果）；沪深300 应传真实内码或 `000300.SH`。

> 长区间多指数时行数会较大，需要窄窗时用 `beginDate`/`endDate` 收敛。

## 4. 调用示例

```bash
# 单指数、缺省日期窗口
python "<SKILL_DIR>/scripts/api_client.py" invoke index-value-analysis '{"indexObject":["631101"]}'
# 指定区间（返回区间内逐日估值快照）
python "<SKILL_DIR>/scripts/api_client.py" invoke index-value-analysis '{"indexObject":["631101"],"beginDate":"yyyy-MM-dd","endDate":"yyyy-MM-dd"}'
# 多指数同区间对比
python "<SKILL_DIR>/scripts/api_client.py" invoke index-value-analysis '{"indexObject":["000300.SH","000905.SH"],"endDate":"yyyy-MM-dd"}'
```

## 5. 返回数据路径与关键字段

读 `$.data`（`recordCount` + `records[]`，一行 = 指数 × 截止日；保持上游返回顺序）：

| 字段 | 含义 |
|---|---|
| `indexobject` / `indexcode` / `indexname` | 指数内码 / 代码 / 名称 |
| `enddate` | 截止日期（`yyyy-MM-dd`，该交易日的估值快照） |
| `indextotalmv` | 指数总市值（**亿元**） |
| `indexnegotiablemv` | 指数流通市值（**亿元**） |
| `indexfreefloatmv` | 指数自由流通市值（**亿元**） |
| `indexcomponentnum` | 指数成分股数量 |
| `pelyr` / `pettm` | 市盈率 PE(LYR) / 滚动市盈率 PE(TTM) |
| `pettmpercentile` | 滚动 PE(TTM) 历史百分位（**%**） |
| `pbmrq` / `pblf` | 市净率 PB(MRQ) / PB(LF) |
| `pblfpercentile` | PB(LF) 历史百分位（**%**） |
| `pcflyr` / `pcfttm` | 市现率 PCF(LYR) / 滚动 PCF(TTM) |
| `pslyr` / `psttm` | 市销率 PS(LYR) / 滚动 PS(TTM) |
| `dividendratiolyr` / `dividendratio` | 股息率 / 滚动股息率（**%**） |
| `riskpremium` | 股债风险溢价（**%**） |
| `peg` | PEG |

## 6. 数据口径

- 单位**已由上游换算完毕**：市值三列为亿元，历史百分位/股息率/股债风险溢价为百分数；展示直接用，**不要二次换算、不要再 ×100**。
- `pettmpercentile` / `pblfpercentile` 是**历史分位**（0~100 的百分数），不是 0~1 小数，不要当概率重新换算。
- `enddate` 为日期字符串（`yyyy-MM-dd`），无时区换算；一行即一个交易日的快照，区间入参返回逐日序列，**不聚合、不取末值**。
- 数值列可能为 `null`：上游对无该项数据的指数不赋值（部分指数类型不提供 PEG/股债风险溢价等），展示为「—」，**不要当 0**。
- 平台不重排返回顺序，按上游顺序输出。

> 挂账（Q-IVA-01）：市值是否亿元、分位/股息率是否百分数等量级，取自 DS 源码口径，首次线上调用后按实测校准。

## 7. 空数据与异常值语义

| 现象 | 含义与处理 |
|---|---|
| 400 `PARAM_INVALID` | `indexObject` 缺失/空列表/元素格式非法；日期非 `yyyy-MM-dd` |
| 200 + `NO_DATA` | 内码解析不到、区间内无估值数据——**可解析但无数据，不是错误** |
| 503 `DEGRADED` | 上游取数失败（超时/拒连等），无降级数据；可稍后重试或告知用户数据暂不可用 |
| 字段为 `null` | 该指数类型不提供此项，展示「—」 |

## 8. 前置条件与调用限制

- 需已配置平台凭证、网关可达；调用间隔建议 ≥ 3 秒。
- `indexObject` 传**内码**或带后缀聚源代码；只有指数名称/6 位净码时，先按 `index-resolve` 取得内码（见 `workflows/index-code-resolution.md`）。
- 单次可传多只指数；行数 = 指数数 × 区间交易日数，长区间多指数时行数会很大，需要单点估值时只传 `endDate`。

## 9. 相关工作流

- `workflows/index-code-resolution.md`：只给指数名称或 6 位净码时，先解析为内码/聚源代码再调用本接口。
