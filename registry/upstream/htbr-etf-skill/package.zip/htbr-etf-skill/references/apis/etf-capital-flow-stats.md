# etf-capital-flow-stats

| 项 | 值 |
|---|---|
| `api_id` | `etf-capital-flow-stats` |
| 服务端登记名 | 场内基金市场资金流向统计 |
| 领域 | etf |
| 资料完整度 | 完整（请求 + 响应 + 口径均有） |

## 1. 功能与适用场景

返回**全市场 ETF** 按日 / 周 / 月 / 季 / 年聚合的资金流向统计：全市场及股票型 / 债券型 / 商品型 / 货币型 / 跨境型五类的流入、流出、净流入与 ETF 数量。

适用：用户问「今天全市场 ETF 资金净流入多少」「这周股票型 ETF 流入多少」「市场上 ETF 有几只」。

## 2. 不适用场景与易混接口

- **与 `etf-capital-flow` 的区别**：那个是**单只基金**逐日明细；本接口是**全市场汇总**（无基金入参）。
- 与 `etf-pr-list` / `etf-pr-components` 无关（那两者是申赎清单）。
- 不提供分钟级数据。

## 3. 请求参数

| 参数 | 类型 | 必填 | 规则 |
|---|---|---|---|
| `beginDate` | string | 否 | 起始日（含），格式 **`yyyyMMdd`**；空 = `endDate` 往前 1 年；格式非法 → 400 |
| `endDate` | string | 否 | 截止日（含），格式 **`yyyyMMdd`**；空 = 今天；格式非法 → 400 |
| `indexCycle` | integer | 否 | `1` 日（**默认**）/ `2` 周 / `3` 月 / `4` 季 / `5` 年；**其他值 400** |
| `unit` | integer | 否 | `1` 元 / `2` 千元 / `3` 万元（**默认**）/ `4` 百万 / `5` 千万 / `6` 亿 / `7` 十亿；非法兜底万元 |

> ⚠ **入参日期是 `yyyyMMdd` 紧凑格式**（与 `etf-capital-flow` 同款），传 `yyyy-MM-dd` 这类带横杠的写法会直接 **400 `PARAM_INVALID`**。
> 日期本身可以不传（缺省为「今天往前一年」「今天」）；但**一旦要传，就必须是 `yyyyMMdd`**。
> 返回的 `records[].enddate` 反而是 `yyyy-MM-dd` —— 入参出参格式不同，勿混用。

## 4. 调用示例

```bash
# 按月、以亿元展示（区间需写成 yyyyMMdd 紧凑格式）
python "<SKILL_DIR>/scripts/api_client.py" invoke etf-capital-flow-stats '{"beginDate":"yyyyMMdd","endDate":"yyyyMMdd","indexCycle":3,"unit":6}'

# 全部缺省：今天往前一年、逐日、万元
python "<SKILL_DIR>/scripts/api_client.py" invoke etf-capital-flow-stats '{}'
```

## 5. 返回数据路径与关键字段

读 `$.data`，**每周期一行**，`records[]` 按 `enddate` **降序**：

| 字段组 | 字段 | 含义 |
|---|---|---|
| 周期 | `enddate` | 该周期内**最后一个交易日** |
| 全市场 | `alletftotalbuyvalue` / `alletftotalsellvalue` / `alletfnetbuyvalue` / `alletfnum` | 流入 / 流出 / 净流入（已按 `unit` 换算，4 位小数）/ ETF 数量（只，去重内码） |
| 股票型 | `stocketf*` 四件套 | 同上口径 |
| 债券型 | `bondetf*` 四件套 | 同上 |
| 商品型 | `commodityetf*` 四件套 | 同上 |
| 货币型 | `monetaryetf*` 四件套 | 同上 |
| 跨境型(QDII) | `qdiietf*` 四件套 | 同上 |

## 6. 数据口径

- 金额字段**已按 `unit` 换算**（`unit=6` 即亿元），4 位小数，展示直接用。
- `enddate` 是**桶内最后一个交易日**，不是自然周期末（如某周只有 4 个交易日，`enddate` 是那周的周四/周五）。
- **不按交易日历补齐空周期**：某个周期没有资金流就不出这一行。
- 分类按基金标签归类；**某只 ETF 没有任何生效标签时，会计入"全市场"桶但不进任何分类桶**
  ⇒ **五类合计可能小于全市场合计**，这是口径本身，不是数据丢失。
- ⚠ 同一笔资金流若命中**跨组的多个生效标签**，会被**重复计入多个分类**（对齐上游口径），
  因此五类相加也可能大于全市场。解释数据时须说明这一点，不要把分类当互斥拆分。
- 只统计 ETF 类基金；非 ETF 的资金流完全不出现在结果里。
- 某周期某分类无数据时输出**金额 0、数量 0**（不是 `null`）。
- 金额按**精确十进制 HALF_UP** 舍入到 4 位；与 DS 对拍时末位可能差 **0.0001**（DS 用 Java double 累加，
  tie 边界偏移），属舍入边界差异，不是数据口径错误。

## 7. 空数据与异常值语义

| 现象 | 含义与处理 |
|---|---|
| 400 `PARAM_INVALID` | `indexCycle` 不在 1–5、`unit` 非整数，或 `beginDate`/`endDate` 不是 `yyyyMMdd`（最常见：误写成 `yyyy-MM-dd`） |
| 200 + 空列表 | 区间内无资金流数据，如实说明 |
| 某分类全为 0 | 该周期无该类型 ETF 的资金流，属正常 |
| 五类合计 ≠ 全市场 | 正常：无标签基金只进全市场；跨组标签会重复计入 |

## 8. 前置条件与调用限制

- 需已配置 API Key（`config.py status` 为 configured），网关可达；调用间隔建议 ≥ 3 秒。
- 无基金入参 —— 不要试图传 `fundCode`（会被忽略）。

## 9. 相关工作流

无。
