# fund-manager-position-detail

| 项 | 值 |
|---|---|
| `api_id` | `fund-manager-position-detail` |
| 服务端登记名 | 基金经理持股明细 |
| 领域 | fund |
| 资料完整度 | 请求/响应结构完整；`rank` 密集排名口径已明确，`ratiochange` 基准期待实测（见第 6 节挂账） |

## 1. 功能与适用场景

返回**基金经理持股明细**：一行 = 基金经理 × 报告期 × 股票，给持仓量（万股）、市值（万元）、占流通股比、占净值比、占比变化、季度涨跌、PE/PB、行业、所属概念与占净值比排名。

适用：用户问「这位经理上季度重仓了哪些股票、每只买了多少」「第一大重仓股占净值多少」「这只股票他加仓还是减仓了」「这些重仓股贵不贵（PE/PB）」。

## 2. 不适用场景与易混接口

- 与 `fund-manager-stock-concentration` 的区别：那个是**集中度汇总**（Top1~Top10 累计占净值比），不给单只股票；本接口给**逐股票明细**。
- 与 `fund-manager-concept-position` 的区别：那个聚合到**概念**维度；本接口是个股（虽然带 `concept` 字段，但一行仍是一只股票）。
- 与 `fund-manager-fund-position` 的区别：那个是**反向查询**（给定股票内码，查哪些基金/经理持有）；本接口是从经理出发看持股。
- 与 `fund-manager-industry-fixed` 的区别：那个聚合到**行业**维度、报告期口径固定；本接口给个股所属行业，可自行聚合但口径可能不同。

> ⚠ **`stockObject` 是股票内码**（`SecuMain.InnerCode` 体系），**不是股票代码**。传 6 位代码会得到 0 行。

## 3. 请求参数

| 参数 | 类型 | 必填 | 规则 |
|---|---|---|---|
| `personalCodes` | integer[]（兼容单值/数字字符串） | 否 | 经理内码列表；不传 = 全量经理；元素非整数 → 400 |
| `stockObject` | integer[]（兼容单值/数字字符串） | 否 | **股票内码**列表；不传 = 全部股票；元素非整数 → 400 |
| `beginDate` | string | 否 | `yyyy-MM-dd`；不传 = 不下推 |
| `endDate` | string | 否 | `yyyy-MM-dd`；不传 = 不下推 |

> **四个参数全部可选**：全不传即「全市场 × 全报告期 × 全股票」，行数在十万量级。**实务上至少带一个收窄条件**（经理或日期区间），否则响应可能过大。

> ⚠ **`personalCodes` 是代码不是姓名**：只有姓名时先走 `fund-manager-resolve`（见 `workflows/manager-name-resolution.md`）。

## 4. 调用示例

```bash
# 单经理、指定报告期区间
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-manager-position-detail '{"personalCodes":[600000001],"beginDate":"yyyy-MM-dd","endDate":"yyyy-MM-dd"}'
# 反查某只股票被哪些经理持有（注意传内码，不是 6 位代码）
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-manager-position-detail '{"stockObject":[1234],"beginDate":"yyyy-MM-dd","endDate":"yyyy-MM-dd"}'
```

## 5. 返回数据路径与关键字段

读 `$.data`（`recordCount` + `records[]`，一行 = 经理 × 报告期 × 股票）：

| 字段 | 含义 |
|---|---|
| `personalobject` / `personalname` | 基金经理代码 / 名称 |
| `reportdate` | 报告期（`yyyy-MM-dd`） |
| `stockobject` / `stockcode` / `stockname` | 证券内码 / 股票代码 / 股票简称 |
| `sharesholding` | 持仓量（**万股**） |
| `circulatingstockratio` | 占流通股比（**%**） |
| `marketvalue` | 市值（**万元**） |
| `netvalueratio` | 占净值比（**%**） |
| `ratiochange` | 占比变化（**%**，可负） |
| `quarterriseandfall` | 季度涨跌（**%**，可负） |
| `pe` / `pb` | 市盈率 / 市净率（倍数） |
| `industryname` | 行业（上游已译文本） |
| `concept` | 所属概念（上游已译文本，可能多值拼接） |
| `rank` | 占净值比排序（**密集排名**，前 10 即重仓股） |

## 6. 数据口径

- **日期键名是 `reportdate`**：同批多数接口用 `enddate`，本接口用 `reportdate`，取字段时别照抄别处。
- **单位：`sharesholding` 万股、`marketvalue` 万元**。展示成「股 / 元」需 ×1e4；平台不换算，**不要重复换算**。
- **四个百分数列上游即百分数**：`circulatingstockratio` / `netvalueratio` / `ratiochange` / `quarterriseandfall`，**不要再 ×100**。
- **`rank` 是密集排名不是行号**：同一占净值比的多只股票共用一个 `rank`，所以 `rank <= 10` 取出的**行数可能多于 10 行**。要「严格前 10 只」需按 `rank` 排序后自行截断。
- **`ratiochange` 可正可负**：负号即相对上期减仓；**不要取绝对值**再描述。
- **`concept` 可能多值拼接**：原样引用，**不要自行拆分或只用第一个**（分隔符待实测，见挂账 Q-FMPD-02）。
- 数值列可能为 `null`（上游用无效值哨兵），展示为「—」，**不要当 0**。

> 挂账（Q-FMPD-01 / 02 / 04）：`ratiochange` 的基准期口径（上一报告期 vs 上一季度）、`concept` 的分隔符、`industryname` 采用的行业标准，均待首次线上调用后按实测补记。

## 7. 空数据与异常值语义

| 现象 | 含义与处理 |
|---|---|
| 400 `PARAM_INVALID` | `personalCodes`/`stockObject` 元素非整数；日期非 `yyyy-MM-dd` |
| 200 + `NO_DATA` | 该经理/该股票/该区间无持股记录——**不是错误**；先查 `stockObject` 是否误传了股票代码而非内码 |
| 503 `DEGRADED` | 上游取数失败（超时/拒连等），无降级数据；可稍后重试或告知用户数据暂不可用 |
| 字段为 `null` | 该期不提供此项，展示「—」 |

> **本接口没有 404 / 409**：纯列表型报表，传不存在的经理内码只返回 200 + `NO_DATA`。

## 8. 前置条件与调用限制

- 需已配置平台凭证、网关可达；调用间隔建议 ≥ 3 秒。
- **至少带 `personalCodes` 或日期区间**：四个参数全不传会拉全市场全报告期，响应体量不可控。
- `stockObject` 只能用**内码**；只有股票代码时先换内码（或改用 `fund-manager-concept-position` 走概念维度）。
- `personalCodes` 只能用**代码**；姓名先 `fund-manager-resolve`。

## 9. 相关工作流

- `workflows/manager-name-resolution.md`：只给经理姓名时，先解析为 `personalCode` 再调用本接口。
