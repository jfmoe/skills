# fund-manager-stage-revenue

| 项 | 值 |
|---|---|
| `api_id` | `fund-manager-stage-revenue` |
| 服务端登记名 | 基金经理阶段收益 |
| 领域 | fund |
| 资料完整度 | 完整（请求 + 响应 + 两个枚举速查表 + 口径均有） |

## 1. 功能与适用场景

返回**基金经理阶段收益**：一行 = 基金经理 × 基金分类口径 × 基金类别 × 时间区间，给区间收益率、年化收益率、同类经理均值与同类排名。

适用：用户问「这位经理近一年赚了多少、年化多少」「跟同类经理比强多少、排第几」「只看他管的股票型基金近 3 年收益」。

## 2. 不适用场景与易混接口

- 与 `fund-manager-revenue-statis` 的区别：那个是**逐报告期序列**（按起止日期看每期收益走势）；本接口是**一组阶段快照**（近 1 周/近 1 年/任职以来这种固定区间）。
- 与 `fund-manager-stage-revenue-rank` 的区别：那个是**排名专表**（多 `rankN` 排名范围），本接口只顺带给一条同类排名字符串。
- 与 `fund-manager-risk-return` 的区别：那个给**风险指标**（波动/回撤/夏普等），本接口只有收益。
- 与 `fund-stage-performance` 的区别：那个主体是**基金产品**，本接口主体是**基金经理**。

## 3. 请求参数

| 参数 | 类型 | 必填 | 规则 |
|---|---|---|---|
| `personalCodes` | integer[]（兼容单值/数字字符串） | **是** | 基金经理**代码**列表；缺失或空列表 → 400；元素非整数 → 400 |
| `fundTypeCode` | integer[]（兼容单值/数字字符串） | 否 | 基金类别，取值见下方速查表；不传 = 全类别；不在表内 → 400 |
| `timeInterval` | string[]（兼容单值） | 否 | 时间区间，取值见下方速查表；不传 = 全区间；不在表内 → 400 |

**`fundTypeCode` 取值（本表为唯一权威）**

| 值 | 含义 |
|---:|---|
| `999` | 全部基金 |
| `1101` | 股票型 |
| `1103` | 混合型 |
| `1105` | 债券型 |
| `1106` | 短期理财债券型 |
| `1109` | 货币型 |
| `1110` | QDII |
| `1111` | FOF |
| `1112` | 基础设施基金 |
| `1113` | 商品基金 |

**`timeInterval` 取值（本表为唯一权威）**

| 值 | 含义 |
|---|---|
| `1` | 近 1 天 |
| `7` | 近 1 周 |
| `30` | 近 1 月 |
| `90` | 近 3 月 |
| `180` | 近 6 月 |
| `365` | 近 1 年 |
| `24` | 近 2 年 |
| `36` | 近 3 年 |
| `60` | 近 5 年 |
| `120` | 近 10 年 |
| `998` | 今年以来 |
| `999` | 任职以来 |

> ⚠ **`timeInterval` 编码不按时间跨度递增**：`24` 是「近 2 年」，排在 `365`「近 1 年」之后；`998`/`999` 是特殊口径。不要按月数自己推算。
> 两个枚举越界会被平台**提前 400**，不会静默返回空结果。

> ⚠ **`personalCodes` 是代码不是姓名**：只有经理姓名时先走 `fund-manager-resolve`（见 `workflows/manager-name-resolution.md`）。

## 4. 调用示例

```bash
# 单经理，全部类别与区间
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-manager-stage-revenue '{"personalCodes":[600000001]}'
# 只看股票型、近 1 年与近 3 年
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-manager-stage-revenue '{"personalCodes":[600000001],"fundTypeCode":[1101],"timeInterval":["365","36"]}'
# 任职以来表现（全类别）
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-manager-stage-revenue '{"personalCodes":[600000001],"timeInterval":["999"]}'
```

## 5. 返回数据路径与关键字段

读 `$.data`（`recordCount` + `records[]`；保持上游返回顺序）：

| 字段 | 含义 |
|---|---|
| `personalobject` / `personalname` | 基金经理代码 / 名称 |
| `enddate` | 截止日期（`yyyy-MM-dd`） |
| `typecode` / `typename` | 基金分类口径代码 / 描述 |
| `fundtypecode` / `fundtypename` | 基金类别代码 / 描述 |
| `timeinterval` / `timeintervaldes` | 时间区间编码 / 中文描述 |
| `weightedavgreturn` | 收益率（**%**） |
| `annualweightedavgreturn` | 年化收益率（**%**） |
| `returntypeavg` | 同类经理收益率均值（**%**） |
| `returntyperank` | 同类经理收益率排名（**字符串**，如 `12/2180`） |

## 6. 数据口径

- **三列收益都是百分数**：`weightedavgreturn` / `annualweightedavgreturn` / `returntypeavg` 上游标注即 `(%)`，展示直接用，**不要再 ×100**。
- **`returntyperank` 是字符串**：「排名/总数」形态（如 `12/2180`），按原文引用，**不要解析成数字**。
- **一行 = 经理 × 分类口径 × 类别 × 区间**：同一经理会因 `typecode`（分类口径）与 `fundtypecode`（类别）不同而多行，**跨口径不可相加或平均**。
- `timeinterval` 是编码、`timeintervaldes` 是上游译好的中文（如「近1年」）；展示用后者，**不要把中文回传当入参**。
- 区间收益与年化收益在「近 1 年」等区间会非常接近（区间恰为一年时相等），属于正常现象。
- `enddate` 为日期字符串（`yyyy-MM-dd`），无时区换算。
- 数值列可能为 `null`（上游用无效值哨兵），展示为「—」，**不要当 0**。
- 平台不重排返回顺序。

## 7. 空数据与异常值语义

| 现象 | 含义与处理 |
|---|---|
| 400 `PARAM_INVALID` | `personalCodes` 缺失/空/非整数；`fundTypeCode` 或 `timeInterval` 不在速查表 |
| 200 + `NO_DATA` | 该经理/类别/区间无收益记录——**不是错误** |
| 503 `DEGRADED` | 上游取数失败（超时/拒连等），无降级数据；可稍后重试或告知用户数据暂不可用 |
| 字段为 `null` | 该口径不提供此项，展示「—」 |

## 8. 前置条件与调用限制

- 需已配置平台凭证、网关可达；调用间隔建议 ≥ 3 秒。
- `personalCodes` 只能用**代码**；姓名先 `fund-manager-resolve`。
- `fundTypeCode` / `timeInterval` 不传时返回**全组合**（行数 = 类别数 × 区间数），需要窄结果时显式传值。

## 9. 相关工作流

- `workflows/manager-name-resolution.md`：只给经理姓名时，先解析为 `personalCode` 再调用本接口。
