# fund-manager-revenue-statis

| 项 | 值 |
|---|---|
| `api_id` | `fund-manager-revenue-statis` |
| 服务端登记名 | 基金经理区间周期收益 |
| 领域 | fund |
| 资料完整度 | 完整（请求 + 响应 + 枚举速查均有；期间标签格式待实测，见第 6 节挂账） |

## 1. 功能与适用场景

返回**基金经理逐期收益序列**：一行 = 基金经理 × 基金分类口径 × 基金类别 × 一个周期（月/季/年），给该期收益率、同类经理均值与同类排名。

适用：用户问「这位经理最近 8 个季度每季赚了多少」「按月看他的收益波动」「近三年逐年收益」「跟同类比每期排第几」「画一条季度收益柱状图」。

## 2. 不适用场景与易混接口

- 与 `fund-manager-stage-revenue` 的区别：那个是**区间快照**（近1周/近1年/任职以来这种固定区间，一次一组），本接口是**逐期序列**（按月/季/年铺开多行）。两者的 `timeInterval` 入参**编码完全不同**（本接口单值 1/3/12；那个是字符串列表 1/7/30/…/998/999）。
- 与 `fund-manager-stage-revenue-rank` 的区别：那个是**排名专表**（多 `rankN`），本接口只顺带一条同类排名字符串。
- 与 `fund-manager-risk-return` 的区别：那个给**风险指标**，本接口只有收益。
- 与 `fund-manager-products-income` 的区别：那个是**逐产品**（一只基金一行），本接口是**逐期**。

## 3. 请求参数

| 参数 | 类型 | 必填 | 规则 |
|---|---|---|---|
| `personalCodes` | integer[]（兼容单值/数字字符串） | **是** | 基金经理**代码**列表；缺失或空列表 → 400 |
| `timeInterval` | integer（**单值，不接受数组**） | **是** | 周期粒度，取值见下方速查表；缺失/不在表内/传数组 → 400 |
| `beginDate` | string | 否 | `yyyy-MM-dd`；不传 = 不下推（上游缺省区间） |
| `endDate` | string | 否 | `yyyy-MM-dd`；不传 = 不下推（上游缺省区间） |
| `fundTypeCode` | integer[]（兼容单值/数字字符串） | 否 | 基金类别，取值见下方速查表；不传 = 全类别；不在表内 → 400 |

**`timeInterval` 取值（本表为唯一权威）**

| 值 | 含义 |
|---:|---|
| `1` | 月度 |
| `3` | 季度 |
| `12` | 年度 |

**`fundTypeCode` 取值（本表为唯一权威）**

| 值 | 含义 |
|---:|---|
| `999` | 全部基金 |
| `1101` | 股票型 |
| `1103` | 混合型 |
| `1105` | 债券型 |
| `1106` | 短期理财债券型 |
| `1109` | 货币型 |
| `1110` | QDII |
| `1111` | FOF |
| `1112` | 基础设施基金 |
| `1113` | 商品基金 |

> ⚠ **本接口的 `timeInterval` 是单值整数、只有三个取值**（1 月度 / 3 季度 / 12 年度）。
> `fund-manager-stage-revenue` 的同名参数是**字符串列表、12 个取值**（近1天…任职以来），**两个接口不能互换参数**。

> ⚠ **`personalCodes` 是代码不是姓名**：只有姓名时先走 `fund-manager-resolve`（见 `workflows/manager-name-resolution.md`）。

## 4. 调用示例

```bash
# 单经理、按季度、缺省区间
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-manager-revenue-statis '{"personalCodes":[600000001],"timeInterval":3}'
# 按月度、指定起止日期、只看股票型
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-manager-revenue-statis '{"personalCodes":[600000001],"timeInterval":1,"beginDate":"yyyy-MM-dd","endDate":"yyyy-MM-dd","fundTypeCode":[1101]}'
# 按年度、近三年
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-manager-revenue-statis '{"personalCodes":[600000001],"timeInterval":12,"beginDate":"yyyy-MM-dd","endDate":"yyyy-MM-dd"}'
```

## 5. 返回数据路径与关键字段

读 `$.data`（`recordCount` + `records[]`，一行 = 经理 × 分类口径 × 类别 × 一期；保持上游返回顺序）：

| 字段 | 含义 |
|---|---|
| `personalcode` / `chinesename` | 基金经理代码 / 名称 |
| `enddate` | 该期截止日期（`yyyy-MM-dd`） |
| `typecode` / `typename` | 基金分类口径代码 / 描述 |
| `fundtypecode` / `fundtypename` | 基金类别代码 / 描述 |
| `timeinterval` | 该期**期间标签**（字符串；不是入参的 1/3/12） |
| `weightedavgreturn` | 该期收益率（**%**） |
| `returntypeavg` | 同类经理收益率均值（**%**） |
| `returntyperank` | 同类经理收益率排名（**字符串**，如 `12/2180`） |

## 6. 数据口径

- **逐期序列不是快照**：一次调用出多期，按 `timeinterval` 排序展示即可；不要只取首行当「区间收益」。
- **`timeinterval`（出参）≠ `timeInterval`（入参）**：入参是粒度编码 1/3/12，出参是**该期的期间标签字符串**，二者不可互推。
- **两列收益都是百分数**：`weightedavgreturn` / `returntypeavg`，展示直接用，**不要再 ×100**。
- **`returntyperank` 是字符串**（`12/2180` 形态），按原文引用，**不要解析成数字**。
- **跨口径不可聚合**：不同 `typecode` / `fundtypecode` 的行不可相加或平均。
- `enddate` 为日期字符串（`yyyy-MM-dd`），无时区换算。
- 数值列可能为 `null`（上游用无效值哨兵），展示为「—」，**不要当 0**。
- 平台不重排返回顺序。

> 挂账（Q-FMRV-01）：`timeinterval` 期间标签的确切格式（`2026Q2` 还是 `2026-06`）首次线上调用后按实测校准。

## 7. 空数据与异常值语义

| 现象 | 含义与处理 |
|---|---|
| 400 `PARAM_INVALID` | `personalCodes` 缺失/空/非整数；`timeInterval` 缺失/不在 1·3·12/传数组；`fundTypeCode` 不在速查表；日期非 `yyyy-MM-dd` |
| 200 + `NO_DATA` | 区间内无该经理/类别的收益记录——**不是错误** |
| 503 `DEGRADED` | 上游取数失败（超时/拒连等），无降级数据；可稍后重试或告知用户数据暂不可用 |
| 字段为 `null` | 该期/该口径不提供此项，展示「—」 |

## 8. 前置条件与调用限制

- 需已配置平台凭证、网关可达；调用间隔建议 ≥ 3 秒。
- **`timeInterval` 必填且只能一个值**：要看月/季/年三种粒度，需调三次。
- `personalCodes` 只能用**代码**；姓名先 `fund-manager-resolve`。
- 行数 = 经理数 × 类别数 × 期数；期数由 `beginDate`/`endDate` 与粒度共同决定，长区间 + 月度会很多行。

## 9. 相关工作流

- `workflows/manager-name-resolution.md`：只给经理姓名时，先解析为 `personalCode` 再调用本接口。
