# fund-manager-products-income

| 项 | 值 |
|---|---|
| `api_id` | `fund-manager-products-income` |
| 服务端登记名 | 基金经理历任产品收益信息 |
| 领域 | fund |
| 资料完整度 | 请求/响应结构完整；`incumbent`/`isexpire` 字面与 `managementtime` 形态待线上实测（见第 6 节挂账） |

## 1. 功能与适用场景

返回**基金经理历任产品收益信息**：一行 = 基金经理 × 其管理过的一只基金（按任职区间），给任职天数、最新规模、综合得分、任职累计/年化收益、六档区间回报、任职风险指标（alpha/beta/夏普/最大回撤/索提诺/卡玛/年化波动率）。

适用：用户问「这位经理管过哪些基金、每只任期赚了多少」「他在这只基金上任职几年、年化多少」「历史产品里哪只回撤最大、夏普最高」「在任产品现在多大、近一年表现如何」。

## 2. 不适用场景与易混接口

- 与 `fund-manager-experience` 的区别：那个是**历任公司与职务履历**；本接口是**历任产品与任期收益**。
- 与 `fund-manager-stage-revenue` 的区别：那个是经理层**聚合**阶段收益（按类别/区间），不含单只产品。
- 与 `fund-manager-risk-return` 的区别：那个是经理层**风险收益面板 + 同类排名**。
- 与 `fund-manager-history` 的区别：那个从**基金**看历任经理；本接口从**经理**看历任基金，方向相反。
- 与 `fund-basic-info` / `fund-asset-size` 的区别：那些是**单只基金**的资料/规模，不含经理任期维度。

## 3. 请求参数

| 参数 | 类型 | 必填 | 规则 |
|---|---|---|---|
| `personalCode` | integer[]（兼容单值/数字字符串） | **是** | 基金经理**内码**列表；缺失或空列表 → 400；元素非整数 → 400 |

> ⚠ **参数名是单数 `personalCode`**：与 `fund-manager-risk-return` 的 `personalCodes`（复数）不同，两个接口不能互换参数名。

> ⚠ **本接口没有日期、也没有基金过滤**：一次返回该经理**全部历任产品**，要缩小范围请在结果侧按 `accessiondate` / `dimissiondate` / `fundcode` 筛选，不要传不存在的 `beginDate`/`endDate`。

> ⚠ **`personalCode` 是代码不是姓名**：只有经理姓名时先走 `fund-manager-resolve`（见 `workflows/manager-name-resolution.md`）。

## 4. 调用示例

```bash
# 单经理全部历任产品
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-manager-products-income '{"personalCode":[600000001]}'
# 多经理对比
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-manager-products-income '{"personalCode":[600000001,600000002]}'
```

## 5. 返回数据路径与关键字段

读 `$.data`（`recordCount` + `records[]`；共 **40 字段**，按块记）：

| 块 | 字段 |
|---|---|
| 身份与基金 | `personalobject` / `personalname` / `fundobject` / `fundcode` / `fundname` |
| 三套分类 | `datacode` + `dataname`（证监会）、`firstassetcatcode` + `firstassetcatname`（聚源一级）、`secassetcatcode` + `secassetcatname`（聚源二级）、`thirdassetcatcode` + `thirdassetcatname`（聚源三级） |
| 任职信息 | `postname` / `incumbent` / `accessiondate` / `dimissiondate` / `managementtime` / `isexpire` / `tradingday` |
| 规模与得分 | `scale`（**万元**）/ `aspectscore` |
| 任职收益 | `performance`（累计%）/ `incomey`（年化%）/ `unitnv`（元） |
| 区间回报 | `threemonth` / `sixmonth` / `singleyear` / `threeyear` / `fiveyear` / `tenyear` / `sincestart` / `sincethisyear`（均 %） |
| 任职风险指标 | `alpha` / `beta` / `sharperatio` / `maxdrawdown`（%）/ `sortinoratio` / `calmarratio` / `returnsd`（%） |

## 6. 数据口径

- **一行 = 经理 × 一只历任基金（任职区间）**：同一基金若经理先后两段任职，可能出现两行，靠 `accessiondate`/`dimissiondate` 区分。
- **带 `%` 的列是百分数**（任职累计/年化收益、八档区间回报、最大回撤、年化波动率），展示直接用，**不要再 ×100**。
- **`scale` 单位是万元**（不是元、不是亿元），对外表述要带单位；换算成亿元需 ÷10000。
- **`alpha` / `beta` / `sharperatio` / `sortinoratio` / `calmarratio` 是倍数**，不是百分数。
- **`managementtime` 是字符串**（任职天数），按原文引用，不要当数字参与计算前先确认格式。
- **三套分类并存**：证监会分类与聚源一/二/三级口径不同，**不可混用**；回答时说清用的是哪套。
- **`dimissiondate` 为 `null` = 仍在任**（与 `incumbent` 一起判断），展示为「至今」。
- 排序照上游：`personalobject` 升序 + `accessiondate` 降序（到任新的在前），平台不重排。
- 日期列为 `yyyy-MM-dd` 字符串，无时区换算。
- 数值列可能为 `null`（上游用无效值哨兵），展示为「—」，**不要当 0**。

> 挂账（Q-MPI-01 / Q-MPI-02 / Q-MPI-03）：`incumbent`/`isexpire` 的字面取值、`managementtime` 的确切形态、`scale`/`unitnv` 量级，首次线上调用后按实测校准。

## 7. 空数据与异常值语义

| 现象 | 含义与处理 |
|---|---|
| 400 `PARAM_INVALID` | `personalCode` 缺失/空列表/元素非整数 |
| 200 + `NO_DATA` | 该经理无历任产品记录——**不是错误** |
| 503 `DEGRADED` | 上游取数失败（超时/拒连等），无降级数据；可稍后重试或告知用户数据暂不可用 |
| 字段为 `null` | 该产品/该区间不提供此项，展示「—」；`dimissiondate` 为 null 表示在任 |

## 8. 前置条件与调用限制

- 需已配置平台凭证、网关可达；调用间隔建议 ≥ 3 秒。
- `personalCode` 只能用**代码**；姓名先 `fund-manager-resolve`。
- 行数 = 该经理历任基金数（通常几只到几十只），单次别传太多经理。

## 9. 相关工作流

- `workflows/manager-name-resolution.md`：只给经理姓名时，先解析为 `personalCode` 再调用本接口。
