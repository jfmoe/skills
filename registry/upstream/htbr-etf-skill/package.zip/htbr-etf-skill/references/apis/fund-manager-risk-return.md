# fund-manager-risk-return

| 项 | 值 |
|---|---|
| `api_id` | `fund-manager-risk-return` |
| 服务端登记名 | 基金经理风险收益 |
| 领域 | fund |
| 资料完整度 | 请求/响应结构完整；排名串拼接格式与回撤符号约定待线上实测（见第 6 节挂账） |

## 1. 功能与适用场景

返回**基金经理风险收益面板**：一行 = 基金经理 × 基金类别 × 时间区间，横向铺开五组指标——收益、波动率、年化波动率、最大回撤（含相对基准）、夏普比率；每组自带「指标值 + 同类经理均值 + 排名 + 排名分值 + 排名数量 + 截止日期」。

适用：用户问「这位经理波动率多大、最大回撤多深」「夏普比率多少、在同行里什么水平」「收益不错但风险是不是也高」「跟基准比回撤控制得怎么样」。

## 2. 不适用场景与易混接口

- 与 `fund-manager-stage-revenue` 的区别：那个**只有收益**（且可选 `fundTypeCode`/`timeInterval` 收窄）；本接口给**收益 + 全套风险指标**，且**不收窄类别与区间**（输出里铺开）。
- 与 `fund-manager-revenue-statis` 的区别：那个是**逐报告期收益序列**。
- 与 `fund-manager-stage-revenue-rank` 的区别：那个是**排名专表**。
- 与 `fund-manager-image` 的区别：那个是**评分体系**（维度得分/战胜同类百分比），本接口是**数值化的风险收益指标 + 排名**。
- 与 `fund-return-risk` 的区别：那个主体是**基金产品**，本接口主体是**基金经理**。

## 3. 请求参数

| 参数 | 类型 | 必填 | 规则 |
|---|---|---|---|
| `personalCodes` | integer[]（兼容单值/数字字符串） | **是** | 基金经理**代码**列表；缺失或空列表 → 400；元素非整数 → 400 |

> ⚠ **本接口只有这一个入参**：**没有** `fundTypeCode`、也没有 `timeInterval`。基金类别与时间区间由上游在输出里铺开（同一经理返回多行）。
> 想按类别/区间收窄，请改用 `fund-manager-stage-revenue`（那个支持 `fundTypeCode` + `timeInterval`，但只有收益没有风险指标）。

> ⚠ **`personalCodes` 是代码不是姓名**：只有经理姓名时先走 `fund-manager-resolve`（见 `workflows/manager-name-resolution.md`）。

## 4. 调用示例

```bash
# 单经理全量面板
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-manager-risk-return '{"personalCodes":[600000001]}'
# 多经理对比
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-manager-risk-return '{"personalCodes":[600000001,600000002]}'
```

## 5. 返回数据路径与关键字段

读 `$.data`（`recordCount` + `records[]`，一行 = 经理 × 类别 × 区间；保持上游返回顺序）。共 **47 字段**，按块记：

| 块 | 字段 |
|---|---|
| 基础维度 | `personalcode` / `chinesename` / `enddate` / `typename` / `fundtypecode` / `fundtypename` / `timeinterval` / `timeintervalint` |
| 收益 | `weightedavgreturn` / `annweightedavgreturn` / `weightedavgreturndate` / `returntypeavg` / `returnrank` / `returnrankscore` / `returnranknum` / `returnrankanddate` |
| 波动率 | `volatility` / `volatilitydate` / `returnsdtypeavg` / `returnsdrank` / `returnsdrankscore` / `returnsdranknum` / `returnsdrankanddate` / `annvolatility` |
| 年化波动率同类 | `annreturnsdtypeavg` / `annreturnsdrank` / `annreturnsdrankscore` / `annreturnsdranknum` |
| 最大回撤 | `maxdrawdown` / `maxdrawdowndate` / `maxddtypeavg` / `maxddrank` / `maxddrankscore` / `maxddranknum` / `maxddrankanddate` |
| 相对基准最大回撤 | `obmaxdrawdown` / `obmaxddtypeavg` / `obmaxddrank` / `obmaxddrankscore` / `obmaxddranknum` |
| 夏普比率 | `sharperatio` / `sharperatiodate` / `sharpetypeavg` / `sharperatioranki` / `sharperatiorankscore` / `sharperatioranknum` / `sharperatiorank` |

## 6. 数据口径

- **带「(%)」语义的列是百分数**：收益、波动率、年化波动率、最大回撤（含相对基准）及各自同类均值，展示直接用，**不要再 ×100**。
- **`sharperatio` / `sharpetypeavg` 是倍数不是百分数**，不要 ×100。
- **排名类列是字符串**：`returnrank` / `returnsdrank` / `annreturnsdrank` / `maxddrank` / `obmaxddrank` / `sharperatioranki` 形如 `156/2180`，按原文引用，**不要解析成数字**。
- **`*anddate` 与 `sharperatiorank` 是「排名(截止日期)」串**（不是排名本身）：`returnrankanddate`、`returnsdrankanddate`、`maxddrankanddate`、`sharperatiorank`。要排名用不带 `anddate` 的那个；夏普比率的排名是 `sharperatioranki`（多一个 `i`），**这两个极易看错**。
- **一行 = 经理 × 类别 × 区间**：同一经理多行，跨 `fundtypecode` 或 `timeintervalint` 不可相加或平均。
- `timeinterval` 是文本、`timeintervalint` 是排序用数字：排序用后者，展示用前者。
- 日期列（`enddate` 与四组 `*date`）为 `yyyy-MM-dd` 字符串，无时区换算。
- 数值列可能为 `null`（上游用无效值哨兵），展示为「—」，**不要当 0**。
- 平台不重排返回顺序。

> 挂账（Q-FMRR-01 / Q-FMRR-02）：「排名(截止日期)」串的确切拼法与 `maxdrawdown` 的符号约定，首次线上调用后按实测校准。

## 7. 空数据与异常值语义

| 现象 | 含义与处理 |
|---|---|
| 400 `PARAM_INVALID` | `personalCodes` 缺失/空列表/元素非整数 |
| 200 + `NO_DATA` | 该经理无风险收益记录——**不是错误** |
| 503 `DEGRADED` | 上游取数失败（超时/拒连等），无降级数据；可稍后重试或告知用户数据暂不可用 |
| 字段为 `null` | 该口径不提供此项，展示「—」 |

## 8. 前置条件与调用限制

- 需已配置平台凭证、网关可达；调用间隔建议 ≥ 3 秒。
- `personalCodes` 只能用**代码**；姓名先 `fund-manager-resolve`。
- 行数 = 经理数 × 类别数 × 区间数（通常几十行/经理），单次别传太多经理。

## 9. 相关工作流

- `workflows/manager-name-resolution.md`：只给经理姓名时，先解析为 `personalCode` 再调用本接口。
