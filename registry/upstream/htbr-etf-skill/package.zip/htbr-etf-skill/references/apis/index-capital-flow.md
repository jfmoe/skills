# index-capital-flow

| 项 | 值 |
|---|---|
| `api_id` | `index-capital-flow` |
| 服务端登记名 | 指数资金流向 |
| 领域 | index |
| 资料完整度 | 完整（请求 + 113 列响应全集均有） |

## 1. 功能与适用场景

返回**指数层面的分档资金流向**：一行 = 一个指数 × 一个截止日，六个档位（小单 / 中单 / 大单 / 超大单 / 全单 / 主力）各给 16 个指标——买入额、卖出额、买入量、卖出量、买入笔数、卖出笔数、净买入额、净买入量，以及对应的「主动」口径（主动买入额/卖出额/买入量/卖出量/买入笔数/卖出笔数/净主动买入额/净主动买入量）；另有 12 个「净（主动）流入持续天数」列。

适用：用户问「沪深300 这几天主力资金是净流入还是净流出、流了多少」「超大单今天买了多少、卖了多少」「中小单是不是在接盘（小单净买入为正、大单净卖出）」「主力资金连续几天净流入了」「这个指数今天的主动买盘强不强」。

## 2. 不适用场景与易混接口

- 与 `index-margin` 的区别：那个是**融资融券余额/买入额/偿还额**（杠杆口径）；本接口是**分档成交资金流**（按单笔金额分档），两者含义与列集完全不同，不可互推。
- 与 `etf-capital-flow` / `etf-capital-flow-stats` 的区别：那两个是**单只场内基金**逐日四档、以及**全市场/五类汇总**；本接口是**指数聚合**口径，入参是指数代码。三者报表不同，数字不可对照。
- 与 `index-daily-quote` / `index-multi-period-quote` 的区别：那两个是行情（价格、成交量额）；本接口不含任何价位字段，只有资金流分档。
- 与 `index-value-analysis` / `index-pe-bands` 的区别：那两个是估值面，与资金流无关。

## 3. 请求参数

| 参数 | 类型 | 必填 | 规则 |
|---|---|---|---|
| `indexObject` | string[]（兼容单字符串/逗号分隔串） | **是** | **指数内码或带后缀聚源代码**（可混传），如 `["3145"]`（沪深300）、`["000300.SH"]`；含 `.` 的值先转内码（转换失败即丢该值），不含 `.` 的原样当内码（非数字 → 400）；全空 → 400 |
| `beginDate` | string | **是** | `yyyy-MM-dd`；缺失/空 → 400 |
| `endDate` | string | **是** | `yyyy-MM-dd`；缺失/空 → 400 |

> ⚠ **6 位净码别直接传**：`000300` 不含 `.`，会被当内码 `300`（结果 200 + 0 行）。要么传内码 `3145`，要么传带后缀代码 `000300.SH`；只有指数名称时先按 `index-resolve` 取 `innerCode`（见 `workflows/index-code-resolution.md`）。

## 4. 调用示例

```bash
# 沪深300 的资金流：内码 3145 与聚源代码 000300.SH 等价
python "<SKILL_DIR>/scripts/api_client.py" invoke index-capital-flow '{"indexObject":["000300.SH"],"beginDate":"yyyy-MM-dd","endDate":"yyyy-MM-dd"}'
# 多指数（内码/代码可混传）+ 限定区间
python "<SKILL_DIR>/scripts/api_client.py" invoke index-capital-flow '{"indexObject":["3145","000905.SH"],"beginDate":"yyyy-MM-dd","endDate":"yyyy-MM-dd"}'
```

## 5. 返回数据路径与关键字段

读 `$.data`（`recordCount` + `records[]`，一行 = 指数 × 截止日；按 `indexObject` 升序、`endDate` 降序，与上游一致），每行恒 **113 键**：

**身份/日期列（5）**

| 字段 | 含义 |
|---|---|
| `gilcode` / `indexobject` / `indexcode` / `indexname` | 聚源代码 / 指数内码 / 指数代码 / 指数简称 |
| `enddate` | 截止日期（`yyyy-MM-dd`） |

**分档指标（96 = 6 档位 × 16 指标，字段名 = 档位前缀 + 指标后缀，全小写）**

| 档位前缀 | 档位 |
|---|---|
| `small` | 小单 |
| `medium` | 中单 |
| `large` | 大单 |
| `huge` | 超大单 |
| `total` | 全单 |
| `main` | 主力 |

| 指标后缀 | 含义 | 指标后缀 | 含义 |
|---|---|---|---|
| `buyvalue` | 买入额 | `activebuyvalue` | 主动买入额 |
| `sellvalue` | 卖出额 | `activesellvalue` | 主动卖出额 |
| `buyvolume` | 买入量 | `activebuyvolume` | 主动买入量 |
| `sellvolume` | 卖出量 | `activesellvolume` | 主动卖出量 |
| `buydeal` | 买入笔数 | `activebuydeal` | 主动买入笔数 |
| `selldeal` | 卖出笔数 | `activeselldeal` | 主动卖出笔数 |
| `netbuyvalue` | 净买入额 | `activenetbuyvalue` | 净主动买入额 |
| `netbuyvolume` | 净买入量 | `activenetbuyvolume` | 净主动买入量 |

> 例：`smallbuyvalue` = 小单买入额；`mainactivenetbuyvalue` = 主力净主动买入额；`totalnetbuyvolume` = 全单净买入量。

**净（主动）流入持续天数（12，整数，单位：天）**

| 字段 | 含义 |
|---|---|
| `smalactinbcontinuousday` | 小单净主动流入持续天数 |
| `medactinetbuycontinuousday` | 中单净主动流入持续天数 |
| `lgactinetbuycontinuousday` | 大单净主动流入持续天数 |
| `hugeactinbcontinuousday` | 超大单净主动流入持续天数 |
| `totactinetbuycontinuousday` | 全单净主动流入持续天数 |
| `mainactinbcontinuousday` | 主力净主动流入持续天数 |
| `smallnetbuycontinuousday` | 小单净流入持续天数 |
| `mediumnetbuycontinuousday` | 中单净流入持续天数 |
| `largenetbuycontinuousday` | 大单净流入持续天数 |
| `hugenetbuycontinuousday` | 超大单净流入持续天数 |
| `totnetbuycontinuousday` | 全单主动流入持续天数 |
| `mainnetbuycontinuousday` | 主力净流入持续天数 |

> ⚠ 这 12 个键名含上游拼写瑕疵（`smalactinb…` 少一个 l、`hugeactinb…`/`mainactinb…` 的 `ActinB`、`medacti…`/`lgacti…`/`totacti…` 的 `Acti` 截断），取字段时**照抄**，不要「顺手修正」，否则取到 `null`。

## 6. 数据口径

- **金额、数量、笔数是三套口径**：`*buyvalue`/`*sellvalue`/`*netbuyvalue`/`*active*value` 是金额，`*volume` 是数量，`*deal` 是笔数。三者的量级不可直接比较，展示时务必带上各自单位。
- **单位已换算**：金额与数量列按上游口径 **÷1e8**、笔数（`*deal`）**÷1e4**，再统一保留两位（上游 `roundNumberUp`：HALF_UP，负数向远离零方向舍入）。引用金额时说明「按接口原值」。
- **持续天数是整数**：0 表示当日该项不满足流入（或该项无数据），不是「无此字段」；按交易日历逐个累计，缺日（停牌/无快照）即断档重计。
- **净额列不自己算**：`*netbuyvalue`、`*netbuyvolume`、`*activenetbuyvalue`、`*activenetbuyvolume` 是上游派生列，别用「买入 − 卖出」重算，也不要校验恒等。
- **档位关系不要臆断**：「主力」通常等于「大单 + 超大单」，但上游未给口径声明，跨档相加前先说明这是推断（见挂账）。
- **`enddate` 是数据日期**（每日快照），区间内逐日一行；按字符串 `yyyy-MM-dd` 承接，无时区换算。
- **指数是聚合口径**：由成分股资金流汇总而来，与单只 ETF 的场内资金流不可比。
- 平台按上游排序输出（`indexObject` 升序、`endDate` 降序）；数值列可能为 `null`（该项无数据），展示为「—」，**不要当 0**。

> 挂账：① 金额/数量/笔数的展示单位（元/亿元、股/万股）上游未标注，引用具体金额时先说「按接口原值」；② 各档位的成交额/成交量划分阈值、以及「主力 = 大单 + 超大单」是否严格成立，上游未声明；③ `totnetbuycontinuousday` 的中文名缺「净」字，按字面照录待确认。

## 7. 空数据与异常值语义

| 现象 | 含义与处理 |
|---|---|
| 400 `PARAM_INVALID` | `indexObject` 缺失/空列表/不含 `.` 的元素非数字；`beginDate`/`endDate` 缺失或非 `yyyy-MM-dd` |
| 200 + `NO_DATA` | 代码解析不到（6 位净码被当内码、带 `.` 的代码转换失败被丢弃）、区间内无资金流数据——**不是错误** |
| 503 `DEGRADED` | 上游取数失败（超时/拒连等），无降级数据；可稍后重试或告知用户数据暂不可用 |
| 字段为 `null` | 该指数该日不提供此项，展示「—」；持续天数列恒有值，`0` = 当日不满足流入（不当 `null`） |

## 8. 前置条件与调用限制

- 需已配置平台凭证、网关可达；调用间隔建议 ≥ 3 秒。
- 一次返回区间内全部行；单行 113 列、指数多 + 区间长时响应会很大，取长历史时建议缩小指数范围或缩短区间。
- `indexObject` 传**指数内码**（`["3145"]`）或**带后缀聚源代码**（`["000300.SH"]`），两者等价、可混传；只有指数名称时先按 `index-resolve` 取 `innerCode`（见 `workflows/index-code-resolution.md`）。

## 9. 相关工作流

- `workflows/index-code-resolution.md`：只给指数名称或 6 位净码时，先解析为代码/内码再调用本接口。
