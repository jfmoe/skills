# index-multi-period-quote

| 项 | 值 |
|---|---|
| `api_id` | `index-multi-period-quote` |
| 服务端登记名 | 指数多周期行情 |
| 领域 | index |
| 资料完整度 | 完整（请求 + 响应 + 口径 + 周期枚举均有） |

## 1. 功能与适用场景

返回**指数在多周期口径下的行情序列**：开高低收/均价/涨跌（点）、涨跌幅与振幅（%）、换手率（%）、成交量（万股）、成交额与指数市值（亿元），一行 = 指数 × 统计周期 × 交易日。

适用：用户问「某指数这段时间按年/半年/季度/月/周/日看的行情」「按周看的开高低收和成交额」「某指数多周期走势对比」。

## 2. 不适用场景与易混接口

- 与 `index-daily-quote` 的区别：那个**逐日 OHLC**、无统计周期入参；本接口可按统计周期取多周期口径。
- 与 `index-range-quote` 的区别：那个是**区间聚合**（一行/指数）；本接口是**序列**（一行/周期×交易日）。
- 与 `index-constituents` / `index-industry-dist` 的区别：那两个是**成分股明细/行业分布**；本接口是**指数自身的行情**。
- 与 `index-basic-info` 的区别：那个是**静态资料**（类型/基期基点/发布机构），无任何行情字段。

## 3. 请求参数

| 参数 | 类型 | 必填 | 规则 |
|---|---|---|---|
| `indexObject` | string[]（兼容单字符串） | **是** | 指数**内码**列表（如 `["631101"]`），或带后缀聚源代码（如 `["GI880001.GI"]`）；空白元素剔除，全空 → 400 |
| `statisticsPeriod` | integer | 否 | 统计周期，取值见下方速查表（`1`~`6`）；**不传 = 按上游缺省周期（日度）**；越界或非整数 → 400 |
| `beginDate` | string | 否 | `yyyy-MM-dd`；不传 = 不下推（上游缺省窗口） |
| `endDate` | string | 否 | `yyyy-MM-dd`；不传 = 不下推（上游缺省窗口） |

**`statisticsPeriod` 取值（本表为唯一权威）**

| 值 | 含义 |
|---:|---|
| `1` | 年度 |
| `2` | 半年度 |
| `3` | 季度 |
| `4` | 月度 |
| `5` | 周度 |
| `6` | 日度 |

> **默认值**：不传 —— 不下推，由上游按缺省周期返回（线上样例为「日度」，即等价 `6`）。
> 出参 `statisticsperiod` 是上游按该编码译好的中文（年度/半年度/季度/月度/周度/日度），可直接展示，**不需要再映射回数字**，也不要自行换算周期。

> ⚠ **`indexObject` 传内码不要传 6 位净码**：上游只对「含 `.` 的值」做聚源代码→内码转换，纯数字一律按内码解析。
> 传 `000300` 会被当成内码 `300`（取到别的标的或空结果）；沪深300 应传真实内码或 `000300.SH`。

## 4. 调用示例

```bash
# 单指数、按上游缺省周期、缺省日期窗口
python "<SKILL_DIR>/scripts/api_client.py" invoke index-multi-period-quote '{"indexObject":["631101"]}'
# 指定日期区间（统计周期仍取上游缺省）
python "<SKILL_DIR>/scripts/api_client.py" invoke index-multi-period-quote '{"indexObject":["631101"],"beginDate":"yyyy-MM-dd","endDate":"yyyy-MM-dd"}'
# 指定统计周期（取值见第 3 节速查表）
python "<SKILL_DIR>/scripts/api_client.py" invoke index-multi-period-quote '{"indexObject":["631101"],"statisticsPeriod":5}'
```

## 5. 返回数据路径与关键字段

读 `$.data`（`recordCount` + `records[]`，一行 = 指数 × 统计周期 × 交易日；保持上游返回顺序，样例为 `tradingday` 降序）：

| 字段 | 含义 |
|---|---|
| `indexname` / `indexcode` | 指数名称 / 指数代码 |
| `indexobject` | 指数内码 |
| `statisticsperiod` | 统计周期（中文描述，如「日度」） |
| `tradingday` | 交易日（`yyyy-MM-dd`） |
| `prevcloseprice` | 前收盘（**点**） |
| `openprice` / `highprice` / `lowprice` / `closeprice` | 开高低收（**点**） |
| `avgprice` | 均价（**点**） |
| `changeofprice` | 涨跌（**点**） |
| `changepct` | 涨跌幅（**%**） |
| `rangepct` | 振幅（**%**） |
| `turnoverrate` | 换手率（**%**） |
| `turnovervolume` | 成交量（**万股**） |
| `turnovervalue` | 成交额（**亿元**） |
| `negotiablemv` | 指数市值（**亿元**） |
| `gilcode` | 聚源代码（如 `GI880001.GI`） |

## 6. 数据口径

- **`changeofprice` 是点差、`changepct` 才是百分比**（= 收盘 − 前收，单位为点），两者不可互换。
- 单位**已由上游换算完毕**：成交量万股、成交额与指数市值亿元、涨跌幅/振幅/换手率百分数；展示直接用，**不要二次换算、不要再 ×100**。
- `statisticsperiod` 是**中文描述不是编码**：上游按入参编码译成「年度/半年度/季度/月度/周度/日度」，可直接展示；不要回传该中文当入参，也不要把「周度」自行改写成「每周」等说法。
- `tradingday` 为日期字符串（`yyyy-MM-dd`），无时区换算。
- 数值列可能为 `null`：上游对无该项数据的指数不赋值（如部分指数类型不提供换手率/指数市值），展示为「—」，**不要当 0**。
- 平台不重排返回顺序，按上游顺序输出。

## 7. 空数据与异常值语义

| 现象 | 含义与处理 |
|---|---|
| 400 `PARAM_INVALID` | `indexObject` 缺失/空列表/元素格式非法；`statisticsPeriod` 非整数或不在 `1`~`6`；日期非 `yyyy-MM-dd` |
| 200 + `NO_DATA` | 内码解析不到、区间内无行情、该周期无数据——**可解析但无数据，不是错误** |
| 503 `DEGRADED` | 上游取数失败（超时/拒连等），无降级数据；可稍后重试或告知用户数据暂不可用 |
| 字段为 `null` | 该指数类型不提供此项，展示「—」 |

## 8. 前置条件与调用限制

- 需已配置平台凭证、网关可达；调用间隔建议 ≥ 3 秒。
- `indexObject` 传**内码**或带后缀聚源代码；只有指数名称/6 位净码时，先按 `index-resolve` 取得内码（见 `workflows/index-code-resolution.md`）。
- 单次可传多只指数，但**行数 = 指数数 × 周期数 × 交易日数**，长区间多指数时行数会很大；需要逐日明细时优先用 `index-daily-quote`。

## 9. 相关工作流

- `workflows/index-code-resolution.md`：只给指数名称或 6 位净码时，先解析为内码/聚源代码再调用本接口。
