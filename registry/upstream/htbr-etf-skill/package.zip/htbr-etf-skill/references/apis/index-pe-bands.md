# index-pe-bands

| 项 | 值 |
|---|---|
| `api_id` | `index-pe-bands` |
| 服务端登记名 | 指数动态PE-Bands |
| 领域 | index |
| 资料完整度 | 完整（请求 + 响应 + 枚举速查 + 带值公式均有；倍数带参数语义待实测，见第 6 节挂账） |

## 1. 功能与适用场景

返回**单指标估值带序列**：一行 = 一个指数 × 一个交易日，含当日收盘价、当日指标值，以及**五条估值带**（下轨/中下轨/中轨/中上轨/上轨）。带值表示「若指数按该指标的历史区间（最小~最大）定价，收盘价会落在哪条带」。

适用：用户问「沪深300 现在 PE 在历史带里偏高还是偏低」「这只指数的 PE-Band 图」「按周看 PB 的估值带」「当前收盘价离上轨还有多远」。

## 2. 不适用场景与易混接口

- 与 `index-value-analysis` 的区别：那个是**估值快照宽表**（一次给 PE/PB/PCF/PS/股息率/市值/分位），**没有 band 概念**、也没有 `type`/`period` 入参；本接口一次只算**一个指标**的带。
- 与 `index-return-risk` 的区别：那个是收益/风险指标长表，不含行情与估值。
- 与 `index-daily-quote` 的区别：那个是纯行情 OHLC，无估值。
- 与 `index-multi-period-quote` 的区别：那个是行情多周期序列，口径是涨跌幅/成交，不是估值。

## 3. 请求参数

| 参数 | 类型 | 必填 | 规则 |
|---|---|---|---|
| `indexObject` | string[]（兼容单字符串） | **是** | 带后缀聚源代码（如 `["000300.SH"]`）或指数**内码**（如 `["631101"]`）；空白元素剔除，全空 → 400 |
| `type` | string | **是** | 指标，取值见下方速查表；不在表内 → 400 |
| `period` | integer | **是** | 频率，取值见下方速查表；不在表内 → 400 |
| `minMultiple` | integer | 否 | 倍数带最小倍数；不传 = 上游缺省；负数/非整数 → 400 |
| `multipleInterval` | integer | 否 | 倍数带间隔；不传 = 上游缺省；负数/非整数 → 400 |
| `bandsCount` | integer | 否 | 估值带条数；不传 = 上游缺省；负数/非整数 → 400 |
| `beginDate` | string | 否 | `yyyy-MM-dd`；不传 = 不下推（上游缺省窗口） |
| `endDate` | string | 否 | `yyyy-MM-dd`；不传 = 不下推（上游缺省窗口） |

**`type` 取值（本表为唯一权威）**

| 值 | 含义 |
|---|---|
| `PE_TTM` | 滚动市盈率 PE(TTM) |
| `PB_LF` | 市净率 PB(LF) |
| `PS_TTM` | 滚动市销率 PS(TTM) |
| `PCF_TTM` | 滚动市现率 PCF(TTM) |
| `DividendRatio` | 股息率 |

**`period` 取值（本表为唯一权威）**

| 值 | 含义 |
|---:|---|
| `0` | 月 |
| `1` | 日 |
| `2` | 周 |
| `3` | 季 |
| `4` | 年 |

> ⚠ **`period` 编码不按时间粒度递增**：月是 `0`、日是 `1`、周是 `2`。不要按「0=日/1=周」的直觉猜，逐字照速查表。
> `type` 严格区分大小写（`pe_ttm` 会被拒）。

> ⚠ **`indexObject` 传内码不要传 6 位净码**：上游只对「含 `.` 的值」做聚源代码→内码转换，纯数字一律按内码解析。
> 传 `000300` 会被当成内码 `300`；沪深300 应传 `000300.SH`。

## 4. 调用示例

```bash
# 沪深300 的 PE-TTM 日频带、缺省日期窗口
python "<SKILL_DIR>/scripts/api_client.py" invoke index-pe-bands '{"indexObject":["000300.SH"],"type":"PE_TTM","period":1}'
# PB(LF) 周频带 + 指定区间
python "<SKILL_DIR>/scripts/api_client.py" invoke index-pe-bands '{"indexObject":["000300.SH"],"type":"PB_LF","period":2,"beginDate":"yyyy-MM-dd","endDate":"yyyy-MM-dd"}'
# 股息率月频带
python "<SKILL_DIR>/scripts/api_client.py" invoke index-pe-bands '{"indexObject":["000300.SH"],"type":"DividendRatio","period":0}'
```

## 5. 返回数据路径与关键字段

读 `$.data`（`recordCount` + `records[]`，一行 = 指数 × 交易日；保持上游返回顺序）：

| 字段 | 含义 |
|---|---|
| `gilcode` / `indexobject` / `indexcode` / `indexname` | 聚源代码 / 内码 / 代码 / 名称 |
| `date` | 日期（`yyyy-MM-dd`） |
| `closeprice` | 收盘价（**点**） |
| `indicatorname` | 指标名称 |
| `indexvalue` | 当日指标值（量纲随 `type`） |
| `lowerband` | 下轨（k=0） |
| `midlowerband` | 中下轨（k=1） |
| `middleband` | 中轨（k=2） |
| `midupperband` | 中上轨（k=3） |
| `upperband` | 上轨（k=4，用区间最大值） |

## 6. 数据口径

- **带值由上游算好**：`band = 收盘价 × (min + k/4 × (max − min)) ÷ 当日指标值`，`min`/`max` 为区间内该指标的最小/最大值；展示直接用，**不要自己重算、不要再 ×100**。
- **五条带的顺序恒为** `lowerband ≤ midlowerband ≤ middleband ≤ midupperband ≤ upperband`（同一行内）；判断「贵不贵」看 `closeprice` 落在哪两条带之间。
- **`indexvalue` 量纲随 `type`**：PE/PB/PS/PCF 是倍数，`DividendRatio` 是百分数；不要统一乘除。
- **`period` 改变行粒度**：日频是一天一行，月/季/年频是聚合后一行一个周期点。
- `date` 为日期字符串（`yyyy-MM-dd`），无时区换算。
- 数值列可能为 `null`（上游用无效值哨兵），展示为「—」，**不要当 0**。
- 平台不重排返回顺序。

> 挂账（Q-IPB-01）：`minMultiple` / `multipleInterval` / `bandsCount` 三个倍数带参数的实际生效语义未实测；一般场景不必传，用上游缺省即可。

## 7. 空数据与异常值语义

| 现象 | 含义与处理 |
|---|---|
| 400 `PARAM_INVALID` | `indexObject` 缺失/空列表/格式非法；`type` 缺失或不在速查表；`period` 缺失或不在速查表；倍数参数负数；日期非 `yyyy-MM-dd` |
| 200 + `NO_DATA` | 内码解析不到、区间内无行情或该指标无值——**不是错误** |
| 503 `DEGRADED` | 上游取数失败（超时/拒连等），无降级数据；可稍后重试或告知用户数据暂不可用 |
| 字段为 `null` | 该日不提供此项，展示「—」 |

## 8. 前置条件与调用限制

- 需已配置平台凭证、网关可达；调用间隔建议 ≥ 3 秒。
- **必须先定 `type` 与 `period`**，两个都是必填；一次调用只出**一个指标**的带，要多指标请分别调用。
- `indexObject` 传**内码**或带后缀聚源代码；只有指数名称/6 位净码时，先按 `index-resolve` 取得内码（见 `workflows/index-code-resolution.md`）。
- 行数 = 指数数 × 区间长度（按 `period` 聚合），长区间多指数时行数会很大。

## 9. 相关工作流

- `workflows/index-code-resolution.md`：只给指数名称或 6 位净码时，先解析为内码/聚源代码再调用本接口。
