# fund-manager-industry-fixed

| 项 | 值 |
|---|---|
| `api_id` | `fund-manager-industry-fixed` |
| 服务端登记名 | 基金经理行业分布（定报） |
| 领域 | fund |
| 资料完整度 | 请求/响应结构完整；分类字段字面与一个下推键大小写待线上实测（见第 6 节挂账） |

## 1. 功能与适用场景

返回**基金经理行业分布**：一行 = 基金经理 × 报告期 × 行业标准 × 行业，给持有比重（%）与市值占比（%）。

适用：用户问「这位经理重仓在哪些行业、电子占多少」「他近几期行业配置怎么变的」「按申万一级看他行业分布」「同行业里他配得比同行重还是轻」。

## 2. 不适用场景与易混接口

- 与 `fund-manager-industry-regular` 的区别：那个是**行业集中度**口径（入参 `holdType`，字段名与本接口的 `posCharacters` **不同**，两者不可复用）；本接口是**行业维度明细占比**。
- 与 `fund-industry-dist` 的区别：那个主体是**基金产品**，不是经理。
- 与 `fund-manager-stock-concentration` 的区别：那个是**股票维度**集中度，本接口是**行业维度**。
- 与 `fund-manager-concept-position` 的区别：那个是**概念**维度，不是行业分类。
- 与 `fund-manager-position-detail` 的区别：那个是**持股明细**（个股），本接口是行业汇总。

## 3. 请求参数

| 参数 | 类型 | 必填 | 规则 |
|---|---|---|---|
| `personalCodes` | integer[]（兼容单值/数字字符串） | **是** | 基金经理**内码**列表；缺失或空列表 → 400 |
| `posCharacters` | integer（单值） | 否 | 持仓类型，仅 `1` 重仓股 / `2` 持仓明细；不传 = 全量；越界/传数组 → 400 |
| `beginDate` | string | 否 | `yyyy-MM-dd`；不传 = 不下推 |
| `endDate` | string | 否 | `yyyy-MM-dd`；不传 = 不下推 |
| `industryStandard` | integer（单值） | 否 | 行业分类标准，**仅 `22` / `37` / `38`**；其余值 → 400 |

> ⚠ **`industryStandard` 只有 22 / 37 / 38 有效**：上游对其它标准**静默丢弃**（返回空集而不报错）。
> 平台已在入口拦掉非法值，所以线上若仍是 0 行，请先确认标准值是否在这三个之内。

> **没有「值=含义」速查表**：22 / 37 / 38 分别对应哪套行业分类（申万/中信/聚源等），上游注释未标明、本技能不预置；需要向用户说明时**按接口返回的 `standard` 字段原样引用**，不要自行命名。

> ⚠ **`personalCodes` 是代码不是姓名**：只有姓名时先走 `fund-manager-resolve`（见 `workflows/manager-name-resolution.md`）。

## 4. 调用示例

```bash
# 单经理、重仓股口径、申万标准（industryStandard 取值见第 3 节）
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-manager-industry-fixed '{"personalCodes":[600000001],"posCharacters":1,"industryStandard":22}'
# 全部持仓类型、全部标准、近两年
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-manager-industry-fixed '{"personalCodes":[600000001],"beginDate":"yyyy-MM-dd","endDate":"yyyy-MM-dd"}'
```

## 5. 返回数据路径与关键字段

读 `$.data`（`recordCount` + `records[]`，一行 = 经理 × 报告期 × 标准 × 行业；按上游顺序）：

| 字段 | 含义 |
|---|---|
| `personalcode` / `chinesename` | 基金经理代码 / 名称 |
| `enddate` | 报告期（`yyyy-MM-dd`） |
| `standard` | 行业标准（上游已译） |
| `industrycode` / `industryname` | 行业代码 / 行业名称 |
| `poscharacter` | 持仓类型（上游已译） |
| `holdingweight` | 持有比重（**%**） |
| `marketvalueratio` | 市值占比（**%**） |

## 6. 数据口径

- **一行 = 经理 × 报告期 × 标准 × 行业**：同一经理多期多标准会铺开很多行；**跨标准不可相加**（不同分类体系的行业集合不同）。
- **两列占比都是百分数**：`holdingweight` / `marketvalueratio`，展示直接用，**不要再 ×100**。
- **`poscharacter`（出参）与 `posCharacters`（入参）大小写不同**：出参是上游译好的文本，入参是 1/2 编码；不要把出参值回传当入参。
- `enddate` 为**报告期**（季末/半年末/年末），不是数据更新日；为 `yyyy-MM-dd` 字符串，无时区换算。
- 同一报告期内各行业 `holdingweight` 之和通常接近 100%（重仓口径则远低于 100%，因为只统计前十大）；判断「是否全口径」看 `poscharacter`。
- 数值列可能为 `null`（上游用无效值哨兵），展示为「—」，**不要当 0**。
- 平台不重排返回顺序（上游为 personalcode 升序 → enddate 降序 → standard 升序 → holdingweight 降序）。

> 挂账（Q-FMIF-01 / Q-FMIF-02）：`standard`/`poscharacter` 的确切字面、以及持仓类型下推键的大小写，首次线上调用后按实测校准。

## 7. 空数据与异常值语义

| 现象 | 含义与处理 |
|---|---|
| 400 `PARAM_INVALID` | `personalCodes` 缺失/空/非整数；`posCharacters` 不在 1·2；`industryStandard` 不在 22·37·38；日期格式错 |
| 200 + `NO_DATA` | 该经理/报告期/标准无行业分布数据——**不是错误** |
| 503 `DEGRADED` | 上游取数失败（超时/拒连等），无降级数据；可稍后重试或告知用户数据暂不可用 |
| 字段为 `null` | 该行业/该期不提供此项，展示「—」 |

## 8. 前置条件与调用限制

- 需已配置平台凭证、网关可达；调用间隔建议 ≥ 3 秒。
- `personalCodes` 只能用**代码**；姓名先 `fund-manager-resolve`。
- 行数 = 经理数 × 报告期数 × 标准数 × 行业数，长区间多标准时行数会很大；用 `beginDate`/`endDate` 收敛期数。

## 9. 相关工作流

- `workflows/manager-name-resolution.md`：只给经理姓名时，先解析为 `personalCode` 再调用本接口。
