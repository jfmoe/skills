# fund-manager-concept-position

| 项 | 值 |
|---|---|
| `api_id` | `fund-manager-concept-position` |
| 服务端登记名 | 基金经理概念持仓分布 |
| 领域 | fund |
| 资料完整度 | 请求/响应结构完整；`poscharacter` 除 `1` 外的取值与三列排名的分组维度待实测（见第 6 节挂账） |

## 1. 功能与适用场景

返回**基金经理概念持仓分布**：一行 = 基金经理 × 报告期 × 概念 × 持仓类型，给持有规模（万元）、持有比重（%）、占权益类市值比重及三项排名。

适用：用户问「这位经理重仓押注在哪些概念/主题上」「某个概念他配了多少、占净值几个点」「他的概念集中度在同行里排第几」「重仓口径和全部持股口径下的概念分布差别」。

## 2. 不适用场景与易混接口

- 与 `fund-manager-position-detail` 的区别：那个是**个股明细**（一只股票一行，含持仓量/PE/PB/行业）；本接口是**概念聚合**，看不到具体股票。
- 与 `fund-manager-industry-fixed` 的区别：那个是**行业**维度（申万/中信等分类标准）；本接口是**概念**维度（题材/主题）。
- 与 `fund-manager-fund-position` 的区别：那个是股票 → 基金的反查，无数值列；本接口在概念维度给规模与占比。
- 与 `fund-manager-stock-concentration` 的区别：那个是 TopN 累计占净值比，不按任何维度分组。

> ⚠ 想知道「这个概念里具体是哪几只股票」，必须另外调 `fund-manager-position-detail`——本接口只到概念粒度。

## 3. 请求参数

| 参数 | 类型 | 必填 | 规则 |
|---|---|---|---|
| `personalCodes` | integer[]（兼容单值/数字字符串） | **是** | 经理代码列表；缺失/空列表 → 400；元素非整数 → 400 |
| `beginDate` | string | 否 | `yyyy-MM-dd`；不传 = 不下推 |
| `endDate` | string | 否 | `yyyy-MM-dd`；不传 = 不下推 |

> ⚠ **没有「持仓类型」入参**：`poscharacter` 只是**出参标注**（`1` = 重仓股，其他 = 全部持股），上游**不做过滤、两类都返回**。本接口因此不设该参数——即使设了也只会被上游静默忽略。

> ⚠ **三个同批接口的经理入参拼写都不同**：本接口 `personalCodes`（复数）、`fund-manager-stock-concentration` 用 `personalObject`、`fund-manager-products-income` 用 `personalCode`。**逐字照抄，不要归一化**。

> `personalCodes` 只能用**代码**；只有姓名时先走 `fund-manager-resolve`（见 `workflows/manager-name-resolution.md`）。

## 4. 调用示例

```bash
# 单经理、指定报告期区间
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-manager-concept-position '{"personalCodes":[600000001],"beginDate":"yyyy-MM-dd","endDate":"yyyy-MM-dd"}'
# 单经理、最新报告期（不带 endDate）
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-manager-concept-position '{"personalCodes":[600000001],"beginDate":"yyyy-MM-dd"}'
```

## 5. 返回数据路径与关键字段

读 `$.data`（`recordCount` + `records[]`，一行 = 经理 × 报告期 × 概念 × 持仓类型）：

| 字段 | 含义 |
|---|---|
| `personalcode` / `chinesename` | 经理代码 / 名称 |
| `reportdate` | 报告期（`yyyy-MM-dd`） |
| `poscharacter` | 持仓类型（**出参标注**：`1` = 重仓股，其他 = 全部持股） |
| `conceptcode` / `conceptname` | 概念代码 / 名称 |
| `marketvalue` | 持有规模（**万元**） |
| `marketvaluerank` | 持有规模排名（组内序号） |
| `holdingweight` | 持有比重（**%**） |
| `holdingweightrank` | 持有比重排名（组内序号） |
| `ratioinstockportfolio` | 占权益类市值比重（**%**） |
| `ratioinstockportfoliorank` | 占权益类市值比重排名（组内序号） |

## 6. 数据口径

- **同一概念会出现两行**：`poscharacter` 为重仓股口径一行、全部持股口径一行。**跨类型不可相加、不可平均**；先按 `poscharacter` 过滤再比较。
- **出参按 `poscharacter` 升序**：重仓股在前、全部持股在后。**不要按 `marketvalue` 重排后直接跨类型对比**。
- **三组「指标 + 排名」成对**：`marketvalue`/`marketvaluerank`、`holdingweight`/`holdingweightrank`、`ratioinstockportfolio`/`ratioinstockportfoliorank`。排名是上游算好的**组内序号**，**不要当全局排名引用**。
- **`marketvalue` 单位万元**：展示成「亿元」需 ÷1e4，不要重复换算。
- **两个百分数列上游即百分数**（`holdingweight` / `ratioinstockportfolio`）：**不要再 ×100**、不要自行舍入。
- **`reportdate` 是报告期**（季末/半年末/年末），`yyyy-MM-dd` 字符串，无时区换算。
- 数值列可能为 `null`（上游用无效值哨兵），展示为「—」，**不要当 0**。

> 挂账（Q-FMCP-01 / 02 / 03）：`poscharacter` 除 `1` 之外的具体取值、三列排名的分组维度（经理内排 vs 全市场排）、以及两个百分数的分母差异，均待首次线上调用后按实测补记。

## 7. 空数据与异常值语义

| 现象 | 含义与处理 |
|---|---|
| 400 `PARAM_INVALID` | `personalCodes` 缺失/空列表/元素非整数；日期非 `yyyy-MM-dd` |
| 200 + `NO_DATA` | 该经理/该区间无概念持仓数据——**不是错误** |
| 503 `DEGRADED` | 上游取数失败（超时/拒连等），无降级数据；可稍后重试或告知用户数据暂不可用 |
| 字段为 `null` | 该期不提供此项，展示「—」 |

> **本接口没有 404 / 409**：纯列表型报表。

## 8. 前置条件与调用限制

- 需已配置平台凭证、网关可达；调用间隔建议 ≥ 3 秒。
- **`personalCodes` 必填**：本接口不接受「全量经理」，缺参直接 400。
- 结果行数 ≈ 经理数 × 期数 × 概念数 × 2（两类持仓口径），**回答时先按 `poscharacter` 与报告期过滤再取 TopN**，不要整表复述。

## 9. 相关工作流

- `workflows/manager-name-resolution.md`：只给经理姓名时，先解析为经理代码再调用本接口。
