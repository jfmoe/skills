# fund-manager-industry-regular

| 项 | 值 |
|---|---|
| `api_id` | `fund-manager-industry-regular` |
| 服务端登记名 | 基金经理行业集中度（定报） |
| 领域 | fund |
| 资料完整度 | 请求/响应结构完整；`holdType` 取值集合与 top2/top3 累计语义待线上实测（见第 6 节挂账） |

## 1. 功能与适用场景

返回**基金经理行业集中度**：一行 = 基金经理 × 报告期 × 占比标准 × 行业标准，横向给 Top1 / Top2 / Top3 / Top5 / Top10 行业累计占比。

适用：用户问「这位经理持股集中不集中、第一大行业占多少」「前三大行业合计占多少」「他的行业集中度和同行比高不高」「近几期集中度是升还是降」。

## 2. 不适用场景与易混接口

- 与 `fund-manager-industry-fixed` 的区别：那个是**行业明细占比**（一行一行业，看每个行业具体多少）；本接口是**集中度**（一行一期，只看 TopN 累计）。两者入参字段名不同（`holdType` vs `posCharacters`）。
- 与 `fund-manager-stock-concentration` 的区别：那个是**股票**维度集中度（前 N 大个股），本接口是**行业**维度。
- 与 `fund-manager-bond-concentration` 的区别：那个是**债券**维度（入参 `standard`）。
- 与 `fund-industry-concentration` 的区别：那个主体是**基金产品**，不是经理。

## 3. 请求参数

| 参数 | 类型 | 必填 | 规则 |
|---|---|---|---|
| `personalCodes` | integer[]（兼容单值/数字字符串） | **是** | 基金经理**代码**列表；缺失或空列表 → 400 |
| `holdType` | integer（单值） | **是** | 持仓占比类型；**无预置枚举**（上游未公开清单），只校验整数；非整数/传数组 → 400 |
| `beginDate` | string | **是** | `yyyy-MM-dd`；**本接口日期必填**，缺失即 400 |
| `endDate` | string | **是** | `yyyy-MM-dd`；同上 |
| `industryStandard` | integer（单值） | 否 | 行业分类标准；**无预置枚举**，只校验整数 |

> ⚠ **本接口 `beginDate` / `endDate` 是必填**：同批多数接口日期可选，这里不是——不传直接 400。

> ⚠ **`holdType` 与 `posCharacters` 不是同一个东西**：本接口用 `holdType`（占比口径），`fund-manager-industry-fixed` 用 `posCharacters`（1 重仓股 / 2 持仓明细）。参数名与语义都不同，**不能互换**。

> **没有「值=含义」速查表**：`holdType` 与 `industryStandard` 的取值由上游报表实现决定，本技能不预置清单（预置会挡住上游新增类型）。
> 需要向用户说明时，**按接口返回的 `holdtype` / `industrystandard` 文本原样引用**，不要自行命名。

> ⚠ **`personalCodes` 是代码不是姓名**：只有姓名时先走 `fund-manager-resolve`（见 `workflows/manager-name-resolution.md`）。

## 4. 调用示例

```bash
# 单经理、一个报告期区间（日期必填）
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-manager-industry-regular '{"personalCodes":[600000001],"holdType":1,"beginDate":"yyyy-MM-dd","endDate":"yyyy-MM-dd"}'
# 再限定行业标准
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-manager-industry-regular '{"personalCodes":[600000001],"holdType":1,"industryStandard":22,"beginDate":"yyyy-MM-dd","endDate":"yyyy-MM-dd"}'
```

## 5. 返回数据路径与关键字段

读 `$.data`（`recordCount` + `records[]`，一行 = 经理 × 报告期 × 占比标准 × 行业标准）：

| 字段 | 含义 |
|---|---|
| `personalcode` / `chinesename` | 基金经理代码 / 名称 |
| `enddate` | 报告期（`yyyy-MM-dd`） |
| `holdtype` | 占比标准（上游已译文本） |
| `industrystandard` | 行业标准（上游已译文本） |
| `top1industrypenetration` | 最大重仓行业占比（**%**） |
| `top2industrypenetration` | 前两大重仓行业占比（**%**） |
| `top3industrypenetration` | 前三大重仓行业占比（**%**） |
| `top5industrypenetration` | 前五大累计占比（**%**） |
| `top10industrypenetration` | 前十大累计占比（**%**） |

## 6. 数据口径

- **这是集中度不是明细**：只有 TopN 累计，看不到「具体哪个行业占多少」——那要走 `fund-manager-industry-fixed`。
- **五列 topN 都是百分数**：展示直接用，**不要再 ×100**；且按累计口径应为**单调不减**（top1 ≤ top2 ≤ top3 ≤ top5 ≤ top10）。
- **`holdtype` / `industrystandard` 出参是文本、入参是整数编码**：不要把出参值回传当入参，二者不可互推。
- **跨标准不可比**：不同 `industrystandard` 的行业集合不同，集中度不能横向对比。
- `enddate` 为**报告期**（季末/半年末/年末），为 `yyyy-MM-dd` 字符串，无时区换算。
- 数值列可能为 `null`（上游用无效值哨兵），展示为「—」，**不要当 0**。
- 平台不重排返回顺序。

> 挂账（Q-FMIR-01 / Q-FMIR-02）：`top2`/`top3` 是累计还是单列、`holdType`/`industryStandard` 的取值集合，首次线上调用后按实测校准。

## 7. 空数据与异常值语义

| 现象 | 含义与处理 |
|---|---|
| 400 `PARAM_INVALID` | `personalCodes` 缺失/空/非整数；`holdType` 缺失/非整数；`beginDate`/`endDate` 缺失或格式错 |
| 200 + `NO_DATA` | 该经理/报告期/标准无集中度数据——**不是错误** |
| 503 `DEGRADED` | 上游取数失败（超时/拒连等），无降级数据；可稍后重试或告知用户数据暂不可用 |
| 字段为 `null` | 该期不提供此项，展示「—」 |

## 8. 前置条件与调用限制

- 需已配置平台凭证、网关可达；调用间隔建议 ≥ 3 秒。
- **四个必填**：`personalCodes`、`holdType`、`beginDate`、`endDate`——少一个就 400。
- `personalCodes` 只能用**代码**；姓名先 `fund-manager-resolve`。
- 行数 = 经理数 × 报告期数 × 标准组合数，通常很小（一行一期），可放心按长区间取。

## 9. 相关工作流

- `workflows/manager-name-resolution.md`：只给经理姓名时，先解析为 `personalCode` 再调用本接口。
