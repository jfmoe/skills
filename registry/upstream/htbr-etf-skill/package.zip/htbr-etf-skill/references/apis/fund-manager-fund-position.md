# fund-manager-fund-position

| 项 | 值 |
|---|---|
| `api_id` | `fund-manager-fund-position` |
| 服务端登记名 | 基金经理持股相关基金 |
| 领域 | fund |
| 资料完整度 | 请求/响应结构完整；无待补枚举（本接口无参数枚举、无数值列） |

## 1. 功能与适用场景

返回**基金经理持股 → 相关基金**：一行 = 基金经理 × 报告期 × 股票 × 持有该股的基金，给股票与相关基金的内码 / 代码 / 简称。

适用：用户问「这位经理买过的这些股票，都有哪些基金在持有」「某只股票被这位经理管的哪几只产品同时持有」「这条持仓线属于哪个产品」。

## 2. 不适用场景与易混接口

- 与 `fund-manager-position-detail` 的区别：那个是**正向**（经理 → 每只股票买了多少、占比多少、PE/PB）；本接口是**反查**（每只股票由哪些基金持有），**没有任何数值列**。
- 与 `fund-manager-stock-concentration` 的区别：那个只给 TopN 累计占比，不给基金名单。
- 与 `fund-manager-concept-position` 的区别：那个聚到**概念**维度，不展开到具体基金。

> ⚠ 想知道「买了多少」必须另外调 `fund-manager-position-detail`——**本接口不含任何数量/占比字段**。

## 3. 请求参数

| 参数 | 类型 | 必填 | 规则 |
|---|---|---|---|
| `personalCodes` | integer[]（兼容单值/数字字符串） | 否 | 经理内码列表；不传 = 全市场（上游把「空」与「含 0」都当全市场）；元素非整数 → 400 |
| `beginDate` | string | 否 | `yyyy-MM-dd`；不传 = 不下推 |
| `endDate` | string | 否 | `yyyy-MM-dd`；不传 = 不下推 |

> **三个参数全部可选**：全不传即「全市场 × 全报告期 × 全股票 × 持有该股的基金」的展开，行数远超同批其他接口。**实务上必须带经理或日期区间**。

> ⚠ **传 `[0]` 不是错误**：上游把「含 0」也视为全市场，会返回全量结果，而不是 400。

> `personalCodes` 只能用**代码**；只有姓名时先走 `fund-manager-resolve`（见 `workflows/manager-name-resolution.md`）。

## 4. 调用示例

```bash
# 单经理、指定报告期区间
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-manager-fund-position '{"personalCodes":[600000001],"beginDate":"yyyy-MM-dd","endDate":"yyyy-MM-dd"}'
# 单经理最新报告期（不带 endDate，观察返回的全部期）
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-manager-fund-position '{"personalCodes":[600000001],"beginDate":"yyyy-MM-dd"}'
```

## 5. 返回数据路径与关键字段

读 `$.data`（`recordCount` + `records[]`，一行 = 经理 × 报告期 × 股票 × 相关基金）：

| 字段 | 含义 |
|---|---|
| `personalcode` / `chinesename` | 基金经理代码 / 名称 |
| `reportdate` | 报告期（`yyyy-MM-dd`） |
| `stockinnercode` / `stockcode` / `stockabbr` | 股票内码 / 代码 / 简称 |
| `fundinnercode` / `fundcode` / `fundabbr` | 相关基金内码 / 代码 / 简称 |

## 6. 数据口径

- **本接口没有任何数值指标**：9 列全是内码 / 代码 / 简称。**不要在这里找占比、市值、收益**。
- **同一股票会出现多行**：一只持有它的基金一行。这是反查语义本身，**不是重复数据**，也**不要自行去重**——去重后就丢了「哪些基金持有」这个答案。
- **双数据源合并**：非投资基金的持仓与投资基金穿透后的持仓两侧合并，行结构一致。
- **`reportdate` 是报告期**（季末/半年末/年末），`yyyy-MM-dd` 字符串，无时区换算。
- 内码列可能为 `null`（上游用无效值哨兵），**不要当 0**。

> 挂账（Q-FMFP-01 / 02）：`[0]` 与其它代码混合时上游是否也放宽为全市场、双源合并后是否可能对同一「经理×股票×基金」产生重复行，均待实测。

## 7. 空数据与异常值语义

| 现象 | 含义与处理 |
|---|---|
| 400 `PARAM_INVALID` | `personalCodes` 元素非整数；日期非 `yyyy-MM-dd` |
| 200 + `NO_DATA` | 该经理/该区间无持股相关基金记录——**不是错误**（也可能该经理当期未持股） |
| 503 `DEGRADED` | 上游取数失败（超时/拒连等），无降级数据；可稍后重试或告知用户数据暂不可用 |
| 字段为 `null` | 该行不提供此项（内码缺失），展示为「—」 |

> **本接口没有 404 / 409**：纯列表型报表。

## 8. 前置条件与调用限制

- 需已配置平台凭证、网关可达；调用间隔建议 ≥ 3 秒。
- **必须带收窄条件**（`personalCodes` 或日期区间）：全不传会拉全市场全报告期，响应体量不可控。
- `personalCodes` 只能用**代码**；姓名先 `fund-manager-resolve`。
- 结果行数 ≈ 经理数 × 期数 × 股票数 × 持有基金数，**回答时不要整表复述**，先按股票或基金聚合再呈现。

## 9. 相关工作流

- `workflows/manager-name-resolution.md`：只给经理姓名时，先解析为经理代码再调用本接口。
