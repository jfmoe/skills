# fund-manager-stock-concentration

| 项 | 值 |
|---|---|
| `api_id` | `fund-manager-stock-concentration` |
| 服务端登记名 | 基金经理持股集中度 |
| 领域 | fund |
| 资料完整度 | 请求/响应结构完整；规模分母取数表待实测（见第 6 节挂账） |

## 1. 功能与适用场景

返回**基金经理持股集中度**：一行 = 基金经理 × 报告期，横向给 Top1/2/3/5/10 重仓股的累计占比。

适用：用户问「这位经理持股集中不集中」「第一大重仓股占多少」「前十大合计占几成」「近几期集中度是升还是降」。

## 2. 不适用场景与易混接口

- 与 `fund-manager-position-detail` 的区别：那个是**逐股票明细**（一只一行，含持仓量/PE/PB/行业）；本接口只给**累计占比**，看不到具体是哪只股票。
- 与 `fund-manager-bond-concentration` 的区别：那个是**债券**维度（Top1~Top5）；本接口是**股票**维度。
- 与 `fund-manager-industry-regular` 的区别：那个是**行业**维度集中度；本接口是**个股**维度集中度。
- 与 `fund-manager-concept-position` 的区别：那个按**概念**聚合，不做 TopN 累计。

> ⚠ 想知道「集中在前十大哪些股票」必须另外调 `fund-manager-position-detail`——本接口不返回个股名称。

## 3. 请求参数

| 参数 | 类型 | 必填 | 规则 |
|---|---|---|---|
| `personalObject` | string[]（兼容单值/数字） | **是** | 经理代码列表；缺失/空列表 → 400 |
| `beginDate` | string | 否 | `yyyy-MM-dd`；不传 = 不下推 |
| `endDate` | string | 否 | `yyyy-MM-dd`；不传 = 不下推 |

> ⚠ **三个同批接口的经理入参拼写都不同**：本接口 `personalObject`（单数）、`fund-manager-risk-return` 用 `personalCodes`、`fund-manager-products-income` 用 `personalCode`。**逐字照抄，不要归一化**。

> ⚠ **只校验非空、不校验是整数**：上游对该字段声明的是字符串列表，传非数字串不会 400，而是返回 0 行。

> `personalObject` 只能用**代码**；只有姓名时先走 `fund-manager-resolve`（见 `workflows/manager-name-resolution.md`）。

## 4. 调用示例

```bash
# 单经理、指定报告期区间
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-manager-stock-concentration '{"personalObject":["600000001"],"beginDate":"yyyy-MM-dd","endDate":"yyyy-MM-dd"}'
# 单经理、全部报告期
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-manager-stock-concentration '{"personalObject":["600000001"]}'
```

## 5. 返回数据路径与关键字段

读 `$.data`（`recordCount` + `records[]`，一行 = 经理 × 报告期）：

| 字段 | 含义 |
|---|---|
| `personalcode` / `personalname` | 基金经理内码 / 名称 |
| `reportdate` | 报告期（`yyyy-MM-dd`） |
| `rate` | 最大重仓股占比（%，**Top1 就叫 `rate`，无数字后缀**） |
| `rate2` | 前二大重仓股占比（%） |
| `rate3` | 前三大重仓股占比（%） |
| `rate5` | 前五大重仓股占比（%） |
| `rate10` | 前十大重仓股占比（%） |

## 6. 数据口径

- **没有 `rate1`、也没有 `rate4`**：Top1 是 `rate`，`rate4` 上游不产出。**取字段不要写「rate + N」循环**，也不要报「缺字段」。
- **五档是累计口径**：同一报告期内应满足 `rate ≤ rate2 ≤ rate3 ≤ rate5 ≤ rate10`；不单调先怀疑混了不同报告期或不同经理的行。
- **分母是经理当期规模**（该报告期规模最大那条记录），所以**跨期占比不可简单纵向比较**——规模变了分母就变了。要判断「加仓还是减仓」，用 `fund-manager-position-detail` 的 `ratiochange`。
- **上游即百分数**：展示直接用，**不要再 ×100、不要自行舍入**。
- **`reportdate` 是报告期**（季末/半年末/年末），`yyyy-MM-dd` 字符串，无时区换算。
- 数值列可能为 `null`（上游用无效值哨兵），展示为「—」，**不要当 0**。

> 挂账（Q-FMSC-01）：规模分母具体取哪张表哪一列，规格书未展开。若本接口与 `fund-manager-position-detail` 交叉验证偏差大（前十大之和对不上），优先怀疑分母口径。

## 7. 空数据与异常值语义

| 现象 | 含义与处理 |
|---|---|
| 400 `PARAM_INVALID` | `personalObject` 缺失/空列表；日期非 `yyyy-MM-dd` |
| 200 + `NO_DATA` | 该经理/该区间无集中度数据——**不是错误**；也可能是 `personalObject` 传了非数字串 |
| 503 `DEGRADED` | 上游取数失败（超时/拒连等），无降级数据；可稍后重试或告知用户数据暂不可用 |
| 字段为 `null` | 该期不提供此项，展示「—」 |

> **本接口没有 404 / 409**：纯列表型报表，经理代码传错只返回 200 + `NO_DATA`。

## 8. 前置条件与调用限制

- 需已配置平台凭证、网关可达；调用间隔建议 ≥ 3 秒。
- **`personalObject` 必填**：本接口不接受「全量经理」，缺参直接 400。
- 不传日期会返回该经理**全部历史报告期**（每期一行），行数 = 期数，通常可控。

## 9. 相关工作流

- `workflows/manager-name-resolution.md`：只给经理姓名时，先解析为经理代码再调用本接口。
