# fund-manager-stage-revenue-rank

| 项 | 值 |
|---|---|
| `api_id` | `fund-manager-stage-revenue-rank` |
| 服务端登记名 | 基金经理收益排名 |
| 领域 | fund |
| 资料完整度 | 完整（请求 + 响应 + 两个枚举速查 + 缺省语义均有） |

## 1. 功能与适用场景

返回**基金经理收益排行榜**：一行 = 基金经理 × 基金类别 × 时间区间，给收益率、同类经理均值与「排名/总数」形式的排名串。

适用：用户问「近一年收益最高的基金经理是谁」「股票型经理里排名前 20 的」「今年以来谁跑得最好」「这位经理在同类里排第几（榜单视角）」。

## 2. 不适用场景与易混接口

- 与 `fund-manager-stage-revenue` 的区别：那个是**指定经理**的区间快照（可多类别/多区间，列表入参），排名只是附带字段；本接口是**榜单**（前 N 名，缺省前 10 全市场），入参全是单值可选。
- 与 `fund-manager-revenue-statis` 的区别：那个是**逐期序列**（月/季/年）。
- 与 `fund-manager-risk-return` 的区别：那个是风险指标面板（收益/波动/回撤/夏普 + 同类排名），不是榜单。
- 与 `fund-manager-image` 的区别：那个是**评分体系**排名，不是收益率排名。

## 3. 请求参数

**四个参数全部可选**，都不传 = 全部基金类别 + 近 1 年 + 前 10 名 的全市场榜。

| 参数 | 类型 | 必填 | 规则 |
|---|---|---|---|
| `fundTypeCode` | integer（单值） | 否 | 基金类别，取值见下方速查表；不传 = 全部基金；不在表内/传数组 → 400 |
| `timeInterval` | integer（单值） | 否 | 时间区间，取值见下方速查表；不传 = 近 1 年；不在表内 → 400 |
| `rankN` | integer（单值） | 否 | 取前 N 名，正整数；不传 = 前 10；≤ 0 或非整数 → 400 |
| `personalObject` | integer[]（兼容单值） | 否 | 基金经理内码列表，作为**过滤器**；不传 = 全市场榜 |

**`fundTypeCode` 取值（本表为唯一权威）**

| 值 | 含义 |
|---:|---|
| `999` | 全部基金（缺省） |
| `1101` | 股票型 |
| `1103` | 混合型 |
| `1105` | 债券型 |
| `1106` | 短期理财债券型 |
| `1109` | 货币型 |
| `1110` | QDII |
| `1111` | FOF |
| `1112` | 基础设施基金 |
| `1113` | 商品基金 |

**`timeInterval` 取值（本表为唯一权威）**

| 值 | 含义 |
|---|---|
| `1` | 近 1 天 |
| `7` | 近 1 周 |
| `30` | 近 1 月 |
| `90` | 近 3 月 |
| `180` | 近 6 月 |
| `365` | 近 1 年（缺省） |
| `24` | 近 2 年 |
| `36` | 近 3 年 |
| `60` | 近 5 年 |
| `120` | 近 10 年 |
| `998` | 今年以来 |

> ⚠ **本接口没有 `999`「任职以来」**：`fund-manager-stage-revenue` 有这一项，本接口没有；传 `999` 会被 400 挡住。
> 编码同样**不按时间跨度递增**（`24` 近2年 排在 `365` 近1年 之后）。

> ⚠ **两个枚举都是单值 integer**：`fund-manager-stage-revenue` 的同名参数是**列表**，两个接口参数形状不同，不能照抄。

## 4. 调用示例

```bash
# 全市场榜：全部类别、近 1 年、前 10（等价于空入参）
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-manager-stage-revenue-rank '{}'
# 股票型近 1 年收益前 20
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-manager-stage-revenue-rank '{"fundTypeCode":1101,"timeInterval":365,"rankN":20}'
# 在指定几位经理里取榜单
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-manager-stage-revenue-rank '{"personalObject":[600000001,600000002],"timeInterval":24}'
```

## 5. 返回数据路径与关键字段

读 `$.data`（`recordCount` + `records[]`，一行 = 经理 × 类别 × 区间；按排名升序返回）：

| 字段 | 含义 |
|---|---|
| `fmcode` / `fmname` | 基金经理代码 / 名称 |
| `enddate` | 截止日期（`yyyy-MM-dd`） |
| `fundtypedesc` | 基金类别描述（中文） |
| `timeintervaldesc` | 时间区间描述（中文，如「近1年」） |
| `returnpct` | 收益率（**%**） |
| `peerfmreturnavgpct` | 同类经理收益率均值（**%**） |
| `peerfmreturnrank` | 同类经理收益率排名（**字符串**，如 `1/2180`） |

## 6. 数据口径

- **这是排行榜不是个体查询**：缺省只回前 10 名；`personalObject` 只是**过滤器**，不是「点查某个人」的手段——要查某个人的详细收益请用 `fund-manager-stage-revenue`。
- **排序照上游**：按 `peerfmreturnrank` 的分子（名次）升序，名次小的在前；平台不重排、不再二次截断。
- **两列收益都是百分数**：`returnpct` / `peerfmreturnavgpct`，展示直接用，**不要再 ×100**。
- **`peerfmreturnrank` 是字符串**（`1/2180` 形态），按原文引用；要算百分位需自行拆分子分母。
- **`fundtypedesc` / `timeintervaldesc` 是中文描述**，直接展示；不要把中文回传当入参。
- `enddate` 为日期字符串（`yyyy-MM-dd`），无时区换算。
- 数值列可能为 `null`（上游用无效值哨兵），展示为「—」，**不要当 0**。

> 挂账（Q-FMRK-01 / Q-FMRK-02）：`rankN` 的上限、以及 `personalObject` 与 `rankN` 的组合语义（先全市场排名再筛 vs 池内排名），首次线上调用后按实测校准。

## 7. 空数据与异常值语义

| 现象 | 含义与处理 |
|---|---|
| 400 `PARAM_INVALID` | `fundTypeCode`/`timeInterval` 不在速查表或传数组；`rankN` ≤ 0/非整数；`personalObject` 元素非整数 |
| 200 + `NO_DATA` | 该条件下无排名数据——**不是错误** |
| 503 `DEGRADED` | 上游取数失败（超时/拒连等），无降级数据；可稍后重试或告知用户数据暂不可用 |
| 字段为 `null` | 该行不提供此项，展示「—」 |

## 8. 前置条件与调用限制

- 需已配置平台凭证、网关可达；调用间隔建议 ≥ 3 秒。
- 条数由 `rankN` 控制，**不要指望一次拿全市场所有经理**；需要大范围名单请多次调用或改用其他接口。
- `personalObject` 只能用**代码**；姓名先 `fund-manager-resolve`。

## 9. 相关工作流

- `workflows/manager-name-resolution.md`：用 `personalObject` 过滤榜单前，先把姓名解析为代码。
