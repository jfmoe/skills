# fund-manager-bond-concentration

| 项 | 值 |
|---|---|
| `api_id` | `fund-manager-bond-concentration` |
| 服务端登记名 | 基金经理持债集中度 |
| 领域 | fund |
| 资料完整度 | 请求/响应结构完整；`standard` 取值集合待线上实测（见第 6 节挂账） |

## 1. 功能与适用场景

返回**基金经理持债集中度**：一行 = 基金经理 × 报告期 × 占比标准，横向给 Top1~Top5 重仓**债**的累计占比。

适用：用户问「这位经理债券持仓集中不集中、第一大重仓债占多少」「前五大债券合计占多少」「近几期持债集中度变化」「偏债经理的债券分散度」。

## 2. 不适用场景与易混接口

- 与 `fund-manager-stock-concentration` 的区别：那个是**股票**维度集中度；本接口只看**债券**。
- 与 `fund-manager-industry-regular` 的区别：那个是**行业**维度集中度（入参 `holdType`）；本接口是**个券**维度（入参 `standard`）。
- 与 `fund-manager-position-detail` 的区别：那个是**个股明细**（股票，一只一行）；本接口是债券 TopN 汇总。
- 与 `fund-manager-industry-fixed` 的区别：那个是行业明细占比，与债券个券无关。

> ⚠ **占比标准字段名三个接口各不同**：本接口 `standard`、`fund-manager-industry-regular` 的 `holdType`、`fund-manager-industry-fixed` 的 `posCharacters`——**语义和字段名都不同，不能互换**。

## 3. 请求参数

| 参数 | 类型 | 必填 | 规则 |
|---|---|---|---|
| `standard` | integer（单值） | **是** | 占比标准；**无预置枚举**（上游未公开清单），只校验整数；缺失/非整数/传数组 → 400 |
| `personalCodes` | integer[]（兼容单值/数字字符串） | 否 | 经理代码列表；不传 = 全量；元素非整数 → 400 |
| `beginDate` | string | 否 | `yyyy-MM-dd`；不传 = 不下推 |
| `endDate` | string | 否 | `yyyy-MM-dd`；不传 = 不下推 |

> **没有「值=含义」速查表**：`standard` 的取值由上游报表实现决定，本技能不预置清单。
> 需要向用户说明时，**按接口返回的 `rate` 字段原样引用**，不要自行命名。

> ⚠ **`personalCodes` 是代码不是姓名**：只有姓名时先走 `fund-manager-resolve`（见 `workflows/manager-name-resolution.md`）。

## 4. 调用示例

```bash
# 单经理、指定占比标准
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-manager-bond-concentration '{"standard":1,"personalCodes":[600000001]}'
# 全部经理、限定报告期区间
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-manager-bond-concentration '{"standard":1,"beginDate":"yyyy-MM-dd","endDate":"yyyy-MM-dd"}'
```

## 5. 返回数据路径与关键字段

读 `$.data`（`recordCount` + `records[]`，一行 = 经理 × 报告期 × 占比标准）：

| 字段 | 含义 |
|---|---|
| `personalcode` / `chinesename` | 基金经理内码 / 名称 |
| `reportdate` | 报告期（`yyyy-MM-dd`） |
| `rate` | 占比标准（上游已译文本） |
| `rate1` | 最大重仓债占比 |
| `rate2` | 前二大重仓债占比 |
| `rate3` | 前三大重仓债占比 |
| `rate4` | 前四大重仓债占比 |
| `rate5` | 前五大重仓债占比 |

## 6. 数据口径

- **日期键名是 `reportdate`**：同批多数接口用 `enddate`，本接口用 `reportdate`，取字段时别照抄别处。
- **`rate1`~`rate5` 是逐级累加的 TopN**：按占比降序取前 N 只累加，**已保留 4 位小数**；展示直接用，**不要再 ×100、不要自行再舍入**。
- **`rate` 出参是文本、`standard` 入参是整数编码**：不可互推，不要把 `rate` 值回传当入参。
- **债券维度 ≠ 股票维度**：本接口只看重仓**债**；股票走 `fund-manager-stock-concentration`，行业走 `fund-manager-industry-regular`。
- `reportdate` 为**报告期**（季末/半年末/年末），为 `yyyy-MM-dd` 字符串，无时区换算。
- `rate1..rate5` 单调不减（累计口径）；若出现不单调，先怀疑标准口径混用。
- 数值列可能为 `null`（上游用无效值哨兵），展示为「—」，**不要当 0**。

> 挂账（Q-FMBC-01）：`standard` 的取值集合与出参 `rate` 的对应关系，首次线上调用后按实测补速查表。

## 7. 空数据与异常值语义

| 现象 | 含义与处理 |
|---|---|
| 400 `PARAM_INVALID` | `standard` 缺失/非整数/传数组；`personalCodes` 元素非整数；日期格式错 |
| 200 + `NO_DATA` | 该经理/报告期/标准无持债数据——**不是错误** |
| 503 `DEGRADED` | 上游取数失败（超时/拒连等），无降级数据；可稍后重试或告知用户数据暂不可用 |
| 字段为 `null` | 该期不提供此项，展示「—」 |

## 8. 前置条件与调用限制

- 需已配置平台凭证、网关可达；调用间隔建议 ≥ 3 秒。
- **`standard` 必填**：不知道取什么值时，先用一个已知口径试，再从返回的 `rate` 确认是否为目标口径。
- `personalCodes` 只能用**代码**；姓名先 `fund-manager-resolve`。
- 不传 `personalCodes` 会返回**全量经理**（行数 = 经理数 × 期数），慎用长区间。

## 9. 相关工作流

- `workflows/manager-name-resolution.md`：只给经理姓名时，先解析为 `personalCode` 再调用本接口。
