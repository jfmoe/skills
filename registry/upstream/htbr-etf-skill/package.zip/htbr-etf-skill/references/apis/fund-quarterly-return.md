# fund-quarterly-return

| 项 | 值 |
|---|---|
| `api_id` | `fund-quarterly-return` |
| 服务端登记名 | 季度周期收益 |
| 领域 | fund |
| 资料完整度 | 完整（请求 + 响应 + 口径均有） |

## 1. 功能与适用场景

查询基金的**逐自然季**收益明细。

适用：用户问「每个季度收益怎么样」「季度收益明细」。

## 2. 不适用场景与易混接口

- 要**月度 / 年度**明细用 `fund-monthly-return` / `fund-yearly-return`。
- 要**累计区间收益**用 `fund-return-sum`；要**固定区间 + 同类排名**用 `fund-stage-performance`。

## 3. 请求参数

| 参数 | 类型 | 必填 | 约束 |
|---|---|---|---|
| `fundCode` | string | 是 | 6 位基金代码 |

## 4. 调用示例

```bash
python "<SKILL_DIR>/scripts/api_client.py" invoke fund-quarterly-return '{"fundCode":"510300"}'
```

## 5. 返回数据路径与关键字段

读 `$.data.quarters[]`：

| 字段 | 含义 |
|---|---|
| `tradingDay` | 该季周期截止交易日，**降序（最新在前）** |
| `quarterlyReturn` | 该季收益率（**小数**，`0.0456` = +4.56%） |

## 6. 数据口径

- `quarterlyReturn` 是**小数**不是百分数，展示须 ×100 加 `%`。
- 按**自然季**分组：**1-3 / 4-6 / 7-9 / 10-12 月**。
- **每只基金最早一期收益恒为 `null`**（无上期可比），展示为「—」。
- 上期净值为 0 时返回 `-1.0` —— **除法口径哨兵值，不是真实的 −100%**。
- 历史收益仅客观陈述，不代表未来表现。

## 7. 空数据与异常值语义

- HTTP 200 + 空数组 = 无季度收益数据，如实说明。
- 首期 `null` 与哨兵值 `-1.0` 按上述口径处理。

## 8. 前置条件与调用限制

- 需已配置 API Key（`config.py status` 为 configured），网关可达；调用间隔建议 ≥ 3 秒。

## 9. 相关工作流

无。
