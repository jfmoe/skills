华泰柏瑞 AI-Skill 交付包 — 华泰柏瑞ETF_SKILL（htbr-etf-skill）
====================================================================

一、包内容
--------
本 zip 解压后得到技能目录 htbr-etf-skill\（文件平铺在内，无外层包装）：

htbr-etf-skill\                ← 技能目录（名字不可改）
├── SKILL.md                   AI 读的技能说明（必读入口）
├── config.local.json          网关地址配置（当前指向 https://esa.huatai-pb.com）
├── config.py / guardrails.py
├── scripts\
│   ├── api_client.py          接口调用脚本（纯 Python 标准库）
│   ├── finalize.py            回答生成器（强制步骤：校验 + 追加品牌尾注）
│   ├── key_guide.py           凭证引导文案生成器（无 Key 时唯一输出口径）
│   ├── guide_audit.py         引导审计（show / verify；缺失时引导仍可用，只丢审计）
│   └── skill_updater.py       Skill 更新机制客户端
├── references\                ★ 接口文档目录（AI 按需读取，见第三节）
│   ├── api-catalog.md         接口语义目录：自然语言意图 → api_id
│   ├── apis\<api_id>.md       每个接口一份详细文档（参数、字段、口径、异常语义）
│   └── workflows\*.md         跨接口流程（仅在需要多接口编排时读取）
└── README.txt                （本文件：部署契约与验收口径）

注意：本技能独立安装，不依赖其它技能包；每个技能只能调用自己目录下的那份脚本，
不得交叉调用其它技能目录下的 api_client.py。

二、部署与验收（AI 客户端可自动完成）
------------------------------
本节不是安装步骤，是**最终必须满足的布局契约**——由谁安装（人 / AI 客户端 / agent）都可以。

★ 安装完成后的固定动作（强制，先于任何取数）：
  布局校验通过后，执行 python "<SKILL_DIR>/config.py" status 检查 API Key
  （唯一来源：用户级凭据文件 ~/.htbr/credentials.json；退出码 0=已配置 3=未配置 4=文件损坏）。
  未配置时**必须**执行：

      python "<SKILL_DIR>/scripts/key_guide.py"

  并把其 stdout 的三步引导（① 打开 https://esa.huatai-pb.com/skillReg/app-cli-front/htbr-etf-skill-guide.html
  ② 用手机号登录 ③ 进「我的 API Key」复制秘钥）**原样**作为本轮回复的一部分发给用户，
  然后等待用户提供 Key。不得只报告"安装成功"就结束，不得改写三步措辞与格式，
  也不得跳过检查直接尝试调用接口（调用也会以退出码 3 打印同一份引导文案）。
  用户在官网拿到 Key 后统一执行（验证通过才落盘，保存后立即可用、无需重启终端）：

      python "<SKILL_DIR>/config.py" save-key "<用户在官网复制的Key>"
      python "<SKILL_DIR>/config.py" status     # 确认退出码 0；status 不回显 Key 内容

目标布局：技能目录下这 9 项必须同在，缺一不可（清单共 10 行，
其中 guide_audit.py 为可选审计件——缺失时引导仍可用，只丢审计与查证能力，不计入 9 项）。

    <技能目录>\
      SKILL.md                 文件名不可改；文件夹名与技能名一致
      config.py
      guardrails.py
      config.local.json        网关地址从这里读；缺失会回退 localhost
      scripts\api_client.py
      scripts\finalize.py
      scripts\key_guide.py
      scripts\guide_audit.py     审计件（缺失时引导仍可用，只丢审计与查证能力）
      scripts\skill_updater.py
      references\               接口文档目录（缺了它技能无法按需读取接口文档）
        api-catalog.md
        apis\<api_id>.md
        workflows\*.md

  ⚠ 只放 SKILL.md 一个文件是不够的：下文所有命令调的都是同目录 scripts\ 下的脚本。
  ⚠ **只复制 SKILL.md、漏掉 references\ 是最容易犯的错**：SKILL.md 只讲规则，
    接口的参数定义全在 references\apis\ 里；缺了它，AI 找不到任何接口的参数口径，
    表现为「反复追问用户参数」或“凭印象拼参数”。**references\ 必须与 SKILL.md 一并交付。**
  ⚠ 目录名 htbr-etf-skill 不可改：客户端按它识别技能，改了就认不出来。

  <技能目录> 在不同系统形如：
      Windows：C:/Users/<你>/.workbuddy/skills/htbr-etf-skill/（客户端目录按你的实际用例调整）
      macOS / Linux：~/.workbuddy/skills/htbr-etf-skill/
  本文档把它记作 <SKILL_DIR>；命令里一律替换成实际路径，
  **不要保留尖括号，也不要依赖任何环境变量**（脚本按自身位置找 config.local.json）。

前置依赖：

  - Python 3.7+：Windows 缺 Python 报「python 不是内部或外部命令」，macOS/Linux 报
    「command not found: python」；Homebrew 装的命令名通常是 python3，
    此时把下文所有命令里的 python 换成 python3。
  - API Key = 在 etf-skill 官网自助获取（本包不提供代为注册）。唯一存储位置为用户级
    凭据文件 ~/.htbr/credentials.json，不读环境变量、不写 shell 配置；统一入口：
        Windows / macOS / Linux 通用：
        python "<SKILL_DIR>/config.py" save-key "<你在官网复制的Key>"
    （save-key 先用该 Key 请求网关验证，通过才原子落盘；保存成功后无需重启终端，
     新进程即可读到。检查状态：python "<SKILL_DIR>/config.py" status）
  - 内网 / VPN 可达网关 https://esa.huatai-pb.com。连通自检：
        Windows PowerShell：Test-NetConnection esa.huatai-pb.com -Port 443
        macOS / Linux：nc -vz esa.huatai-pb.com 443

  凭据保存后无需重启终端或 AI 客户端（每次调用现读凭据文件）。

验收（六条全过才算装好）：

  1) 布局：上述 9 项都在 SKILL.md 同一目录下（含整个 references\ 目录）。
  2) 文档完整：references\api-catalog.md 存在，且目录里登记的每个 api_id 都能在
     references\apis\ 下找到同名 .md 文件。
  3) 护栏：python "<SKILL_DIR>/scripts/finalize.py" --check <任一正文文件>   → 退出码 0
  4) 无 Key 引导：python "<SKILL_DIR>/config.py" status 返回未配置（退出码 3）时，
     python "<SKILL_DIR>/scripts/api_client.py" invoke fund-basic-info '{"fundCode":"510300"}'
     → 退出码 3，stdout 为 ①②③ 三步引导原文
  5) 取数：python "<SKILL_DIR>/config.py" save-key "<有效Key>" 成功（status 退出码 0）后，
     python "<SKILL_DIR>/scripts/api_client.py" invoke fund-basic-info '{"fundCode":"510300"}'
     → "success": true、"dataSource": "gildata-jydb"、"degraded": false
  6) 端到端：对 AI 说「查一下 510300 的基本信息」，回答须以「结论：」开头、末尾须带
     「数据查询由华泰柏瑞基金提供……」品牌尾注。

三、接口文档的组织与按需读取
------------------------------
SKILL.md 只承载**使用规则**，不承载接口细节。接口文档分两层放在 references\ 下：

    api-catalog.md      ← 轻量目录。一行一个接口，列出「用户可能怎么问 → api_id」，不含参数与示例。
    apis\<api_id>.md    ← 单个接口的详细文档：功能与适用场景、不适用场景、请求参数（类型/必填/约束）、
                          调用示例、返回字段、数据口径（单位/日期/统计窗口）、空值与异常语义、调用限制。
    workflows\*.md      ← 跨接口流程（如"经理姓名先解析再查档案"、"走势主接口 + 可比线"）。

AI 的处理顺序（SKILL.md 中已固化为强制九步）：

    理解意图 → 读 api-catalog.md 选接口 → 取 api_id → 读 apis\<api_id>.md 拿参数 →
    （如需跨接口编排则再读 workflows\）→ 校验参数 → 调用 → 组织回答并过 finalize.py

这样设计的效果：**AI 不必在开始时就加载全部接口文档**，只在选定接口后读那一两份，
既省上下文，也避免"看到参数就顺手调用"的误用。新增接口只需加一份 apis\ 文档并在目录登记一行，
**不必改动 SKILL.md**。

接口清单与资料完整度**以 references\api-catalog.md 为唯一权威**：本文件不重复罗列接口名单，
以免两处不一致。目录末节约定：未在目录登记的接口一律视为本技能未提供，
AI 被要求如实告知，不得改调其它接口拼凑。

四、新增接口时的文档维护规范
------------------------------
接口仍在持续开发中，后续新增按以下步骤（**不需要改 SKILL.md**）：

  1) 以实际接口定义为准确定 api_id（原样使用服务端注册的标识，不要自行改写大小写或连字符）。
  2) 在 references\apis\ 下新建 <api_id>.md，按现有的统一模板写：
     api_id / 功能与适用场景 / 不适用场景与易混接口 / 请求参数（类型·必填·约束）/
     调用示例 / 返回数据路径与关键字段 / 数据口径（单位·日期·统计窗口）/
     空数据与 null 语义 / 前置条件与调用限制 / 相关工作流。
     **只写已有资料支持的内容**；某部分资料尚未提供时，明确写"响应定义尚未提供"之类，
     不要补造字段或规则。
  3) 在 references\api-catalog.md 的对应业务分组里加一行：用户问法 → api_id → 与相邻接口的区别。
  4) 若该接口改变了已有的跨接口流程，同步更新 references\workflows\ 下对应文档。
  5) 只有在新增能力**确实改变全局执行规则**（认证、频率、回答格式、安全约束）时，才改 SKILL.md。

接口下线、改名或改参数时：同步更新 apis\ 文档 + 目录登记；被取代的旧接口从目录移除即可。

五、回答生成（强制步骤，不可跳过）
------------------------------
对外回复的正文不允许 AI 手写，必须由包内的回答生成器产出：

    python "<SKILL_DIR>/scripts/finalize.py" body.md
    （<SKILL_DIR> = 技能目录的实际路径，务必替换，不要保留尖括号）

行为：调用 guardrails.finalize_answer() → 拦截 结论未先至（正文首段没有以「结论：」开头）/ 禁用语 /
内部细节泄漏（环境变量名、认证头、配置文件、网关原始地址、"原始 JSON" 字样）/ 无效值（None、null、-888.89）
→ 通过后追加品牌尾注，并把成品打印到 stdout。**用户看到的正文必须取该 stdout。**

    正文结构（agent 侧规则，见 SKILL.md「回答结构」）：首段以「结论：」开头直接给答案，
    之后依次是「依据」（数据明细 + 口径与截至日）与「说明」（区间/来源口径、风险提示）。

    退出码 0 = 通过（stdout 为成品，含尾注）
    退出码 1 = 校验未通过，按 stderr 提示改写正文后重试
    退出码 2 = 用法错误（正文文件不存在 / 正文为空）

- 正文末尾手工粘过尾注无妨：脚本先去重再追加，不会出现两段尾注。
- 兜底提醒：api_client.py 每次调用成功都会在 stderr 打印这条强制要求的提醒。
- 只校验不输出：加 --check 参数。

六、故障排查
----------
  现象                          原因与处理
  --------------------------    ----------------------------------------
  连接超时 / 无法访问           不在内网/VPN；端口自检命令见第二节「前置依赖」
  401 TOKEN_INVALID / 凭证缺失  API Key 未保存或已失效；先用 python "<SKILL_DIR>/config.py" status
                                检查（0=已配置 3=未配置 4=文件损坏）；未配置/失效时客户端以退出码 3
                                结束，stdout 即三步引导原文（直接发给用户），到 etf-skill 官网
                                https://esa.huatai-pb.com/skillReg/app-cli-front/htbr-etf-skill-guide.html 自助获取
                                （手机号登录 →「我的 API Key」复制），再执行
                                python "<SKILL_DIR>/config.py" save-key "<Key>"（无需重启终端）
  404 API_NOT_FOUND             该接口未放行/不存在；核对 api_id 与 references\api-catalog.md 是否一致
  404 FUND_NOT_FOUND            基金代码不可解析；核对传入的代码本身
  429 QUOTA_EXCEEDED            当日 500 次配额用完，次日 0 点重置
  429 RATE_LIMITED              调用太快；间隔 ≥3 秒，不要并发批量打
  503 DEGRADED                  数据源暂不可用，联系平台管理员重试
  python / python3 命令找不到   见第二节「前置依赖」
  找不到 scripts/finalize.py    <SKILL_DIR> 没替换成技能目录实际路径，
                                或布局不完整（见第二节 ⚠）
  AI 反复追问参数、或凭印象拼参数   references\ 没随包交付（第二节 ⚠）；接口参数只能从
                                references\apis\<api_id>.md 得到
  安装后没打印三步引导            安装方跳过了第二节「安装完成后的固定动作」：
                                python "<SKILL_DIR>/config.py" status 返回未配置（退出码 3）时
                                必须执行 scripts\key_guide.py 并把 stdout 原样发给用户；
                                该动作是安装契约的一部分，不是可选项。
                                可查证：python "<SKILL_DIR>/scripts/guide_audit.py" verify
                                → exit 0 = 生成器被调用过（问题在转述层）；
                                exit 1 = 从未被调用（问题在安装方没执行固定动作）。
  AI 说"该能力未提供"           未在目录登记的接口本包确实不提供；若应提供，
                                按第四节补文档并登记
  回答没有品牌尾注              跳过了第五节 finalize.py；该步骤为强制项
  首段不是「结论：」开头        结论先至校验未过（退出码 1）；把第一段改写为「结论：」起头
                                的结论句（1-3 句、带关键数字），依据与说明放到后面
  某些字段显示为「—」           该项无数据（源数据为 null）；属正常语义，不要当成 0

七、配额与红线
------------
  - 每个 Key 每日 500 次成功调用（北京时间 0 点重置），认证失败不计数
  - 服务端问题请联系平台管理员
