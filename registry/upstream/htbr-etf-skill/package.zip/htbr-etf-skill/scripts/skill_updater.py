#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""基金数据查询 Skill — 更新机制客户端（零依赖标准库）。

用法:
  python3 scripts/skill_updater.py check            # 手工查看版本差异（自动检查已内嵌 api_client，无需每次手工触发）
  python3 scripts/skill_updater.py update --confirm # 下发更新（必须带 --confirm=用户已明确同意；自动备份+sha256校验）

流程（配合 SKILL.md「Skill 更新机制」小节）:
  1. 版本自动检查已内嵌 scripts/api_client.py：每会话首次业务调用自动静默 check，
     发现新版时 stderr 输出 [SKILL_UPDATE_REQUIRED]，由调用方向用户展示差异并征得同意。
  2. 用户明确同意后执行 update --confirm：拉取服务端最新 skill 包（zip 二进制 base64），
     本地解压后逐文件按字节对比、备份被覆盖文件、写盘；完成后提示重启会话生效。
     不带 --confirm 直接运行 update 会被拒绝执行（防止绕过"征得用户同意"环节）。

安全:
  - 文件路径仅允许 skill 目录内相对路径（拒绝 ../、绝对路径、隐藏段）；
  - 下载内容按 sha256 与内容双重校验，与本地文件相同时跳过；
  - 不打印 api_key/token 明文。
契约: docs/htbr-ai-skill/02-接口契约.md 附录 H（skill 更新机制）。
"""
from __future__ import annotations

import base64
import hashlib
import io
import json
import os
import re
import shutil
import sys
import zipfile
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from api_client import _get_token, _post, _err_code, _trace_id  # noqa: E402

SKILL_ID = "htbr-etf-skill"
SKILL_ROOT = Path(__file__).resolve().parent.parent  # skills/htbr-etf-skill/
SKILL_MD = SKILL_ROOT / "SKILL.md"
BACKUP_DIR = SKILL_ROOT / ".backup"
FRONTMATTER_VERSION = re.compile(r"^version\s*:\s*(\S+)\s*$", re.M)
CONFIRM_FLAG = "--confirm"  # update 命令强制要求：代表用户已明确同意更新

# 允许下发的文件白名单（服务端包 = 交付目录快照；此处防御性限制，避免意外路径写入）
ALLOWED_EXT = {".md", ".py", ".json", ".txt", ".yml", ".yaml"}


def local_version() -> str:
    """读本地 SKILL.md frontmatter 的 version 字段；缺失视为空（触发更新提示）。"""
    try:
        text = SKILL_MD.read_text(encoding="utf-8")
    except OSError:
        return ""
    m = FRONTMATTER_VERSION.search(text)
    return m.group(1) if m else ""


def _post_skill(path: str, payload: dict) -> dict:
    """带 Token 调用 skill 接口；401 换新 Token 重试一次。失败抛 SystemExit。"""
    status, resp, _ = _post(path, payload, bearer=_get_token())
    if status == 401 and _err_code(resp) in ("TOKEN_EXPIRED", "TOKEN_INVALID"):
        status, resp, _ = _post(path, payload, bearer=_get_token(force_refresh=True))
    if status == 200 and isinstance(resp, dict) and resp.get("success"):
        return resp
    code = _err_code(resp)
    if status == 404 or code == "API_NOT_FOUND":
        raise SystemExit("skill 更新接口不存在（404）：请确认网关已部署 /api/v1/skill/** 路由与应用模块。")
    trace = _trace_id(resp)
    hint = f"（trace_id: {trace}）" if trace else ""
    msg = ""
    if isinstance(resp, dict):
        err = resp.get("error") or {}
        msg = str(err.get("message") or "") if isinstance(err, dict) else ""
    raise SystemExit(f"skill 更新接口调用失败: HTTP {status}{' ' + msg if msg else ''}{hint}")


def check() -> dict:
    """版本校验：返回服务端响应 data（含 latestVersion/updateRequired/breaking/changelog）。"""
    return _post_skill("/skill/version/check", {
        "skillId": SKILL_ID,
        "currentVersion": local_version(),
    })["data"]


def _safe_relative_path(raw: str) -> Path:
    """校验服务端下发路径安全：仅允许 skill 根内相对路径，拒绝穿越/绝对路径。"""
    if not raw or "\x00" in raw:
        raise SystemExit(f"非法文件路径: {raw!r}")
    p = Path(raw.replace("\\", "/"))
    if p.is_absolute() or ".." in p.parts:
        raise SystemExit(f"非法文件路径（拒绝目录穿越）: {raw!r}")
    if any(seg.startswith(".") for seg in p.parts):
        raise SystemExit(f"非法文件路径（拒绝隐藏段）: {raw!r}")
    if p.suffix.lower() not in ALLOWED_EXT:
        raise SystemExit(f"非法文件类型: {raw!r}（允许: {sorted(ALLOWED_EXT)}）")
    target = (SKILL_ROOT / p).resolve()
    if not target.is_relative_to(SKILL_ROOT.resolve()):
        raise SystemExit(f"非法文件路径（越出 skill 根目录）: {raw!r}")
    return p


def _sha256(content: str) -> str:
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def _load_package(data: dict) -> list[tuple[Path, bytes]]:
    """从响应 data 提取待更新文件（相对路径 → 字节内容）。优先 zip 载荷（字节级保真，md 零漂移），
    旧版 files（无 package）时回退逐文件文本（向后兼容）。路径安全校验沿用 _safe_relative_path。"""
    pkg = data.get("package")
    if isinstance(pkg, dict) and pkg.get("encoding") == "base64" and pkg.get("format") == "zip":
        raw = base64.b64decode(pkg.get("data") or "")
        expect = pkg.get("sha256") or ""
        if expect and hashlib.sha256(raw).hexdigest() != expect:
            raise SystemExit("skill 包 zip 整体 sha256 校验失败，已中止更新（本地未做任何修改）。")
        entries: list[tuple[Path, bytes]] = []
        with zipfile.ZipFile(io.BytesIO(raw)) as zf:
            for info in zf.infolist():
                if info.is_dir():
                    continue
                rel = _safe_relative_path(info.filename)
                entries.append((rel, zf.read(info)))
        if not entries:
            raise SystemExit("skill 包 zip 为空，无法更新。")
        return entries
    files = data.get("files")
    if isinstance(files, list) and files:
        out: list[tuple[Path, bytes]] = []
        for f in files:
            rel = _safe_relative_path(str(f.get("path") or ""))
            content = f.get("content") or ""
            expect = f.get("sha256") or ""
            if expect and _sha256(content) != expect:
                raise SystemExit(f"文件 {rel} sha256 校验失败，已中止更新（本地未做任何修改）。")
            out.append((rel, content.encode("utf-8")))
        return out
    raise SystemExit("服务端未返回可用的 skill 包载荷，无法更新。")


def update() -> dict:
    """下发最新 skill 包：先取服务端目标版本，再备份被覆盖文件 → 字节对比 → 写盘。返回摘要。

    契约 H.2：/skill/package 的 version 参数是「本次要拉取的目标版本」，不是本地版本；
    直接传 local_version() 会在本地落后于服务端时被 400 拒绝（版本不可用）。
    载荷为 zip 二进制（base64），本地解压后逐文件按字节对比与写入，保证 md 等文件格式零漂移。
    """
    latest = check().get("latestVersion") or ""
    if not latest:
        raise SystemExit("服务端未返回 latestVersion，无法确定目标版本。")
    if local_version() and local_version() == latest:
        print(f"本地已是最新版本（{latest}），无需更新。")
        return {"skillId": SKILL_ID, "version": latest,
                "changed": [], "skipped": [], "backed": []}
    data = _post_skill("/skill/package", {"skillId": SKILL_ID, "version": latest})["data"]
    entries = _load_package(data)
    changed, skipped, backed = [], [], []
    for rel, content in entries:
        target = SKILL_ROOT / rel
        if target.is_file() and target.read_bytes() == content:
            skipped.append(str(rel))
            continue
        # 备份旧文件（仅被覆盖时）
        if target.is_file():
            backup = BACKUP_DIR / rel
            backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, backup)
            backed.append(str(rel))
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
        changed.append(str(rel))
    # 清理空备份目录不必要：保留供回滚
    return {"skillId": data.get("skillId"), "version": data.get("version"),
            "changed": changed, "skipped": skipped, "backed": backed}


def _print_check(d: dict) -> None:
    local_v = local_version() or "（本地无版本信息）"
    print(f"本地版本:   {local_v}")
    print(f"最新版本:   {d.get('latestVersion')}")
    print(f"是否需要更新: {'是' if d.get('updateRequired') else '否'}")
    if d.get("breaking"):
        print("⚠ 主版本升级（breaking）：更新后行为可能变化，请谨慎确认。")
    if d.get("changelog"):
        print("变更说明:\n" + d["changelog"])


def main(argv: list[str]) -> int:
    if len(argv) < 2:
        print(__doc__.strip(), file=sys.stderr)
        return 2
    cmd = argv[1]
    if cmd == "check":
        _print_check(check())
        return 0
    if cmd == "update":
        if CONFIRM_FLAG not in argv[2:]:
            print(
                "拒绝执行：更新前必须先征得用户同意。\n"
                "请先向用户展示版本差异与变更说明（可执行 check 查看），征得明确同意后，\n"
                '再执行：python "<SKILL_DIR>/scripts/skill_updater.py" update --confirm',
                file=sys.stderr,
            )
            return 2
        summary = update()
        if not summary["changed"] and not summary["backed"]:
            return 0  # 无需更新时 update() 已打印提示
        print(f"skill 已更新到 {summary['version']}：")
        if summary["changed"]:
            print("  更新: " + ", ".join(summary["changed"]))
        if summary["skipped"]:
            print("  未变跳过: " + ", ".join(summary["skipped"]))
        if summary["backed"]:
            print(f"  备份位置: {BACKUP_DIR}（共 {len(summary['backed'])} 个文件）")
        print("更新完成，请重启当前会话使新 skill 生效。")
        return 0
    print(__doc__.strip(), file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
