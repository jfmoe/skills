#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""基金 Skill — 最终回答生成器（强制步骤的唯一入口）。

本脚本是「回答用户前必须执行」的强制环节：把 AI 写好的答案正文交给
guardrails.finalize_answer() 校验（结论先至 / 禁用语 / 内部细节泄漏 / 无效值），
通过后追加品牌尾注并打印成品。**对外回复的正文必须取本脚本的 stdout。**

用法:
  python scripts/finalize.py body.md          # 从文件读正文
  python scripts/finalize.py -                # 从标准输入读正文
  python scripts/finalize.py --check body.md  # 只校验，不打印成品（自检/CI）

退出码:
  0  校验通过（stdout = 可直接作为回复的成品文本，含品牌尾注）
  1  校验失败（stderr 给出命中原因与改写提示；须改写正文后重试）
  2  用法错误 / 正文读取失败 / 正文为空

注意:
  - 品牌尾注文案由 guardrails.DISCLAIMER 唯一维护（变更须走 PO 需求变更流程），
    本脚本不重复定义文案，避免两处漂移。
  - 正文末尾若已手工粘过尾注也没关系：finalize_answer() 会先去掉重复尾注再追加，
    不会出现两段尾注。
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from guardrails import finalize_answer  # noqa: E402

USAGE = (
    "用法:\n"
    "  python scripts/finalize.py <正文文件>        # 从文件读正文\n"
    "  python scripts/finalize.py -                 # 从标准输入读正文\n"
    "  python scripts/finalize.py --check <正文文件> # 只校验，不打印成品\n"
    "\n"
    "通过时 stdout 即为可直接回复用户的成品文本（已含品牌尾注）。"
)

REWRITE_HINTS = (
    "改写提示：\n"
    "  - 未结论先至（正文首个非空段不是以「结论：」开头）：把第一段改成 1-3 句结论句，\n"
    "    以「结论：」起头并带上关键数字；依据与口径说明另起段落放在后面\n"
    "    （结构见 SKILL.md「回答结构：结论先至」）。\n"
    "  - 命中禁用语（推荐/建议买入、稳赚、保本等）：改为客观陈述数据与事实。\n"
    "  - 命中内部细节（环境变量名、认证头、配置文件、网关原始地址、原始 JSON 字样）：\n"
    "    面向用户的话术不要暴露内部标识，改为「该接口/该配置」等中性表述。\n"
    "  - 命中 None/null/-888.89 等无效值：说明该项数据本次未返回，不要照抄占位值。"
)


def _read_body(arg: str) -> str:
    """读取正文：`-` 表示 stdin，否则按文件路径读取。"""
    if arg == "-":
        raw = sys.stdin.buffer.read()
    else:
        path = Path(arg)
        if not path.is_file():
            raise OSError(f"正文文件不存在: {path}")
        raw = path.read_bytes()
    return raw.decode("utf-8-sig", errors="replace")


def main(argv: list[str]) -> int:
    args = argv[1:]
    check_only = False
    if args and args[0] == "--check":
        check_only = True
        args = args[1:]
    if len(args) != 1:
        print(USAGE, file=sys.stderr)
        return 2

    try:
        body = _read_body(args[0])
    except OSError as exc:
        print(f"读取正文失败: {exc}", file=sys.stderr)
        return 2

    try:
        final_text = finalize_answer(body)
    except (ValueError, TypeError) as exc:
        print(f"[FAIL] 答案未通过 guardrails 校验: {exc}", file=sys.stderr)
        print(REWRITE_HINTS, file=sys.stderr)
        return 1

    if check_only:
        print(f"[OK] 校验通过（成品长度 {len(final_text)} 字符，尾注已就位）", file=sys.stderr)
        return 0

    print(final_text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
